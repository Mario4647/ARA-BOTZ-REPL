// JANGAN DI GANTI LAH NAMA CREATOR NYA
// HARGAI LAH

const { fetchJosn, kyun, fetchText } = require('./lib/fetcher')
const { color, bgcolor } = require('./lib/color')
let  { yta, ytv, igdl, upload, formatDate } = require('./lib/ytdl')
const { wait, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, start, info, success, close } = require('./lib/functions')
const premium = require("./lib/premium");

const
	{
		WAConnection,
		MessageType,
		Presence,
		MessageOptions,
		Mimetype,
		WALocationMessage,
		WA_MESSAGE_STUB_TYPES,
		WA_DEFAULT_EPHEMERAL,
		ReconnectMode,
		ProxyAgent,
		GroupSettingChange,
		waChatKey,
		mentionedJid,
		processTime,
	} = require("@adiwajshing/baileys")
const fs = require("fs")
const axios = require('axios')
const speed = require("performance-now")
const util = require('util')
const crypto = require('crypto')
const request = require('request')
const { exec, spawn } = require('child_process')
const fetch = require('node-fetch')
const moment = require('moment-timezone')
const ffmpeg = require('fluent-ffmpeg')
const { removeBackgroundFromImageFile } = require('remove.bg')

const _antilink = JSON.parse(fs.readFileSync('./database/antilink.json'))
const _antitoxic = JSON.parse(fs.readFileSync('./database/antitoxic.json'))
const _antivirtex = JSON.parse(fs.readFileSync('./database/antivirtex.json'))
const setting = JSON.parse(fs.readFileSync('./setting.json'))
const config = JSON.parse(fs.readFileSync('./config.js'))
const _registered = JSON.parse(fs.readFileSync('./database/registered.json'))
const ban = JSON.parse(fs.readFileSync('./database/banned.json'))
let nsfww = JSON.parse(fs.readFileSync('./database/nsfww.json'))
let _premium = JSON.parse(fs.readFileSync('./database/premium.json'));
let mute = JSON.parse(fs.readFileSync('./database/mute.json'));
const stick = JSON.parse(fs.readFileSync('./database/stick.json'))
const vn = JSON.parse(fs.readFileSync('./database/vn.json'))

creator = 'Mario 4647'
partner = 'Lipi Cantik🍁'
owner = setting.OwnerNumber
owner2 = setting.OwnerNumber2
botname = setting.BotName
zerokey = setting.ZeroKey
zerkey = setting.ZerKey
ownername = setting.OwnerName
ownername2 = setting.OwnerName2
logo = setting.Logo
recode = setting.Recode
gopay = setting.Gopay
dana = setting.Dana
ovo = setting.Ovo

apikey1 = config.Lolkey
apikey2 = config.Xteam
apikey3 = config.Vhtear
apikey4 = config.Zeks
apikey5 = config.Zero
apikey6 = config.Nurutomo
apikey7 = config.Hunter

//===================《 MODUL EXPORTS  》=====================// 

module.exports = mario4647 = async (mario4647, mek, _welkom) => {
	try {
        if (!mek.hasNewMessage) return
        mek = mek.messages.all()[0]
		if (!mek.message) return
		if (mek.key && mek.key.remoteJid == 'status@broadcast') return
		global.blocked
        	mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
        const content = JSON.stringify(mek.message)
		const from = mek.key.remoteJid
		const { text, extendedText, contact, contactsArray, groupInviteMessage, listMessage, buttonsMessage, location, liveLocation, image, video, sticker, document, audio, product, quotedMsg } = MessageType
		let time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
		let jam = moment().tz("Asia/Jakarta").format("HH:mm:ss");
	    let wita = moment.tz('Asia/Makassar').format('HH:mm:ss')
		let wib = moment.tz('Asia/Jakarta').format('HH:mm:ss')
		let wit = moment.tz('Asia/Jayapura').format('HH:mm:ss')
        let type = Object.keys(mek.message)[0]        
        let cmd = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
        let prefix = /^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*@,;]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*,;]/gi) : '-'          	
        body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'videoMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'extendedTextMessage') && mek.message[type].text.startsWith(prefix) ? mek.message[type].text : (type == 'listResponseMessage') && mek.message[type].singleSelectReply.selectedRowId ? mek.message[type].singleSelectReply.selectedRowId : (type == 'buttonsResponseMessage') && mek.message[type].selectedButtonId ? mek.message[type].selectedButtonId : ''
		budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
		let command = body.slice(1).trim().split(/ +/).shift().toLowerCase()		
		let args = body.trim().split(/ +/).slice(1)
		let isCmd = body.startsWith(prefix)
		let dtod = "6282110232966@s.whatsapp.net"
        let otod = "6282110232966@s.whatsapp.net"
        let zeroo = "Mario 4647"
		let q = args.join(' ')
		let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()
		let d = new Date
		let locale = 'id'
		let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
		let week = d.toLocaleDateString(locale, { weekday: 'long' })
		let calender = d.toLocaleDateString(locale, {
				day: 'numeric',
				month: 'long',
				year: 'numeric'
		       })
		const Verived = "0@s.whatsapp.net"
		const txt = mek.message.conversation
		const botNumber = mario4647.user.jid
		const ownerNumber = [`${owner}@s.whatsapp.net`, `6283862323152@s.whatsapp.net`]
		const isGroup = from.endsWith('@g.us')
		let sender = isGroup ? mek.participant : mek.key.remoteJid
		const totalchat = await mario4647.chats.all()
		const groupMetadata = isGroup ? await mario4647.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
		let isNsfw = isGroup ? nsfww.includes(from) : false
		const conts = mek.key.fromMe ? mario4647.user.jid : mario4647.contacts[sender] || { notify: jid.replace(/@.+/, '') }
        const pushname = mek.key.fromMe ? mario4647.user.name : conts.notify || conts.vname || conts.name || '-'
        
		const isAntiLink = isGroup ? _antilink.includes(from) : false
		const isAntiToxic = isGroup ? _antitoxic.includes(from) : false
		const isWelkom = isGroup ? _welkom.includes(from) : false
		const isAntiVirtex = isGroup ? _antivirtex.includes(from) : false
		const isOwner = ownerNumber.includes(sender)
		const isMybot = isOwner || mek.key.fromMe
		const isPremium = premium.checkPremiumUser(sender, _premium)
		const isMuted = isGroup ? mute.includes(from) : false
		const tamnel = fs.readFileSync('./arabotz/ara2.jpg')
		
//===================《 CONNECTION 1  》=====================// 

		const sendStickerUrl = async(to, url) => {
			console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Downloading sticker'))
				var names = getRandom('.webp')
				var namea = getRandom('.png')
				var download = function (uri, filename, callback) {
					request.head(uri, function (err, res, body) {
						request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
					});
				};
				download(url, namea, async function () {
					let filess = namea
					let asw = names
					require('./lib/exif.js')
					exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
					exec(`webpmux -set exif ./temp/data.exif ${asw} -o ${asw}`, async (error) => {
					let media = fs.readFileSync(asw)
					mario4647.sendMessage(to, media, sticker, {quoted: mek})
					console.log(color(time, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Succes send sticker'))
					});
					});
				});
			}
        const sendWebp = async(from, url) => {
                var names = Date.now() / 10000;
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, './temp' + names + '.png', async function () {
                    console.log('selesai');
                    let ajg = './temp' + names + '.png'
                    let palak = './temp' + names + '.webp'
                    exec(`ffmpeg -i ${ajg} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${palak}`, (err) => {
                        let media = fs.readFileSync(palak)
                        mario4647.sendMessage(from, media, MessageType.sticker,{quoted:mek})
                        fs.unlinkSync(ajg)
                        fs.unlinkSync(palak)
                    });
                });
            }
          mess = {
			wait: 'Wait a minute',
			success: 'Success',
			error: {
				stick: 'Cannot access videos!',
				Iv: 'Invalid link!',
                api: 'Error'
			},
			only: {
				group: 'Only for within the group!',
				ownerG: 'Only for group owners!',
				ownerB: 'Only for bot owners!',
				admin: 'Only for group admins!',
				Badmin: 'Make the bot a group admin!'
			 }
		}
		const sticOwner = (hehe) => {
			ano = fs.readFileSync('./sticker/anime/owner.webp')
			mario4647.sendMessage(hehe, ano, sticker, { quoted: mek})
		}
		const sticNotAdmin = (hehe) => {
			ano = fs.readFileSync('./sticker/anime/notadmin.webp')
			mario4647.sendMessage(hehe, ano, sticker, { quoted: mek})
		}
		const sticAdmin = (hehe) => {
			ano = fs.readFileSync('./sticker/anime/admin.webp')
			mario4647.sendMessage(hehe, ano, sticker, { quoted: mek})
		}
		const sticWait = (hehe) => {
			ano = fs.readFileSync('./sticker/anime/wait.webp')
			mario4647.sendMessage(hehe, ano, sticker, { quoted: mek})
		}
		const sticOk = (hehe) => {
			ano = fs.readFileSync('./sticker/anime/ok.webp')
			mario4647.sendMessage(hehe, ano, sticker, { quoted: mek})
		}
		faketeks = '© Mario 4647'
		const isUrl = (url) => {
        return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
        }
        const reply = (teks) => {
            mario4647.sendMessage(from, teks, text, {quoted:mek})
        }
        const sendMess = (hehe, teks) => {
            mario4647.sendMessage(hehe, teks, text)
        }
        const mentions = (teks, memberr, id) => {
            (id == null || id == undefined || id == false) ? mario4647.sendMessage(from, teks.trim(), extendedText, { contextInfo: { "mentionedJid": memberr } }) : mario4647.sendMessage(from, teks.trim(), extendedText, { quoted: ftrol, contextInfo: { "mentionedJid": memberr } })
        }
        const zero = fs.readFileSync ('./arabotz/ara2.jpg')
        const costum = (pesan, tipe, target, target2) => {
			mario4647.sendMessage(from, pesan, tipe, { quoted: { key: { fromMe: false, participant: `${target}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target2}` } } })
		}
		const runtime = function (seconds) {
  seconds = Number(seconds);
  var d = Math.floor(seconds / (3600 * 24));
  var h = Math.floor((seconds % (3600 * 24)) / 3600);
  var m = Math.floor((seconds % 3600) / 60);
  var s = Math.floor(seconds % 60);
  var dDisplay = d > 0 ? d + (d == 1 ? " hari, " : " Hari, ") : "";
  var hDisplay = h > 0 ? h + (h == 1 ? " jam, " : " Jam, ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " menit, " : " Menit, ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " detik" : " Detik") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
};
var ase = new Date();
                        var jamss = ase.getHours();
                         switch(jamss){
                case 0: jamss = "Selamat Malam✨"; break;
                case 1: jamss = "Selamat Malam✨"; break;
                case 2: jamss = "Selamat Malam✨"; break;
                case 3: jamss = "Selamat Malam✨"; break;
                case 4: jamss = "Sholat Subuh"; break;
                case 5: jamss = "Selamat Pagi🌄"; break;
                case 6: jamss = "Selamat Pagi🌄"; break;
                case 7: jamss = "Selamat Pagi🌄"; break;
                case 8: jamss = "Selamat Pagi🌄"; break;
                case 9: jamss = "Selamat Pagi🌄"; break;
                case 10: jamss = "Selamat Pagi🌄"; break;
                case 11: jamss = "Selamat Siang🌞"; break;
                case 12: jamss = "Sholat Zhuhur"; break;
                case 13: jamss = "Selamat Siang🌞"; break;
                case 14: jamss = "Selamat Siang🌅"; break;
                case 15: jamss = "Sholat Ashar"; break;
                case 16: jamss = "Selamat Sore🌅"; break;
                case 17: jamss = "Selamat Sore🌇"; break;
                case 18: jamss = "Sholat Magrib"; break;
                case 19: jamss = "Sholat Isya"; break;
                case 20: jamss = "Selamat Malam🌌"; break;
                case 21: jamss = "Selamat Malam🌌"; break;
                case 22: jamss = "Selamat Malam🌌"; break;
                case 23: jamss = "Selamat Malam🌌"; break;
            }
            var tampilUcapan = "" + jamss;
    let readmore = "͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏";
     const sotoy = ['🍊 : 🍒 : 🍐','🍒 : 🔔 : 🍊','🍇 : 🍇 : 🍇','🍊 : 🍋 : 🔔','🔔 : 🍒 : 🍐','🔔 : 🍒 : 🍊','🍊 : 🍋 : 🔔',		'🍐 : 🍒 : 🍋','🍐 : 🍐 : 🍐','🍊 : 🍒 : 🍒','🔔 : 🔔 : 🍇','🍌 : 🍒 : 🔔','🍐 : 🔔 : 🔔','🍊 : 🍋 : 🍒','🍋 : 🍋 : 🍌','🔔 : 🔔 : 🍇','🔔 : 🍐 : 🍇','🔔 : 🔔 : 🔔','🍒 : 🍒 : 🍒','🍌 : 🍌 : 🍌']
            const sotoy2 = ['🍊 : 🍒 : 🍐','🍒 : 🔔 : 🍊','🍊 : 🍋 : 🔔','🔔 : 🍒 : 🍐','🔔 : 🍒 : 🍊','🍊 : 🍋 : 🔔',		'🍐 : 🍒 : 🍋','🍊 : 🍒 : 🍒','🔔 : 🔔 : 🍇','🍌 : 🍒 : 🔔','🍐 : 🔔 : 🔔','🍊 : 🍋 : 🍒','🍋 : 🍋 : 🍌','🔔 : 🔔 : 🍇','🔔 : 🍐 : 🍇']
            const sotoy1 = ['🍊 : 🍒 : 🍐','🍒 : 🔔 : ??','🍊 : 🍋 : 🔔','🔔 : 🍒 : 🍐','🔔 : 🍒 : 🍊','🍊 : 🍋 : 🔔',		'🍐 : 🍒 : 🍋','🍊 : 🍒 : 🍒','?? : 🔔 : 🍇','🍌 : 🍒 : 🔔','🍐 : 🔔 : 🔔','🍊 : 🍋 : 🍒','🍋 : 🍋 : 🍌','🔔 : 🔔 : 🍇','🔔 : 🍐 : 🍇']
            const sotoy3 = ['🔔 : 🔔 : 🔔','🍒 : 🍒 : 🍒','🍌 : 🍌 : 🍌']
            const buruh1 = ['🐳','🦈','🐬','🐋','🐟','🐠','🦐','🦑','🦀','🐚']
            const buruh2 = ['🐔','🦃','🐿','🐐','🐏','🐖','🐑','🐎','🐺','🦩']
            const buruh3 = ['🦋','🕷','🐝','🐉','🦆','🦅','🕊','🐧','🐦','🦇']
            const buruh11 = buruh1[Math.floor(Math.random() * (buruh1.length))]
		    const buruh22 = buruh2[Math.floor(Math.random() * (buruh2.length))]
		    const buruh33 = buruh3[Math.floor(Math.random() * (buruh3.length))]
		const listmsg = (from, title, desc, list) => { // ngeread nya pake rowsId, jadi command nya ga keliatan
            let po = mario4647.prepareMessageFromContent(from, {"listMessage": {"title": title,"description": desc,"buttonText": "LIST MENU","footerText": "Created By Mario 4647🍁","listType": "SINGLE_SELECT","sections": list}}, {})
            return mario4647.relayWAMessage(po, {waitForAck: true})
        }
		
		
//===================《 BUTTON  》=====================// 

        const sendButton = async (from, context, fortext, but, mek) => {
            buttonMessages = {
                contentText: context,
                footerText: fortext,
                buttons: but,
                headerType: 1
            }
            mario4647.sendMessage(from, buttonMessages, buttonsMessage, {
                quoted: ftrol
            })
        }
        const sendButImage = async (from, context, fortext, img, but, mek) => {
            jadinya = await mario4647.prepareMessage(from, img, image)
            buttonMessagesI = {
                imageMessage: jadinya.message.imageMessage,
                contentText: context,
                footerText: fortext,
                buttons: but,
                headerType: 4
            }
            mario4647.sendMessage(from, buttonMessagesI, buttonsMessage, {
                quoted: ftrol,
                contexInfo: adyt
            })
        }
const Sendbutdocument = async(id, text1, desc1, file1, doc1, but = [], options = {}) => {
media = file1
kma = doc1
mhan = await mario4647.prepareMessage(from, media, document, kma)
const buttonMessages = {
documentMessage: mhan.message.documentMessage,
contentText: text1,
footerText: desc1,
buttons: but,
headerType: "DOCUMENT"
}
mario4647.sendMessage(id, buttonMessages, MessageType.buttonsMessage, options)
}
const sendButMessage = (id, text1, desc1, but = [], options = {}) => {
const buttonMessage = {
contentText: text1,
footerText: desc1,
buttons: but,
headerType: 1,
};
mario4647.sendMessage(
id,
buttonMessage,
MessageType.buttonsMessage,
options
)
}
async function sendButLocation(id, text1, desc1, gam1, but = [], options = {}) {
let buttonMessages = { locationMessage: { jpegThumbnail: gam1 }, contentText: text1, footerText: desc1, buttons: but, headerType: 6 }
return mario4647.sendMessage(id, buttonMessages, MessageType.buttonsMessage, options)
}
//sendButLoc(id/from, "string", "string", image, but, mek)
function _0x49e8(){const _0x2abf1f=['128458zaqRph','15LuvETp','32FoIOpf','By\x20:\x20Mario4647','307917pLgBPR','AraBotz~Mario4647','127514DLEruK','2301110zFGGkR','11iUrhyl','5IBSTLg','sendMessage','2099160NwtLDQ','672988HpVyoZ','1059558OLmAKI'];_0x49e8=function(){return _0x2abf1f;};return _0x49e8();}(function(_0x4b5fea,_0xcd96a7){const _0xd54c3c=_0x9a06,_0x555513=_0x4b5fea();while(!![]){try{const _0x4e06eb=parseInt(_0xd54c3c(0x12b))/0x1+parseInt(_0xd54c3c(0x123))/0x2*(parseInt(_0xd54c3c(0x12c))/0x3)+-parseInt(_0xd54c3c(0x129))/0x4*(parseInt(_0xd54c3c(0x126))/0x5)+-parseInt(_0xd54c3c(0x12a))/0x6+-parseInt(_0xd54c3c(0x128))/0x7+parseInt(_0xd54c3c(0x12d))/0x8*(parseInt(_0xd54c3c(0x12f))/0x9)+-parseInt(_0xd54c3c(0x124))/0xa*(-parseInt(_0xd54c3c(0x125))/0xb);if(_0x4e06eb===_0xcd96a7)break;else _0x555513['push'](_0x555513['shift']());}catch(_0x5da84c){_0x555513['push'](_0x555513['shift']());}}}(_0x49e8,0x2960e));function _0x9a06(_0x41e8cb,_0x44ab09){const _0x49e8d9=_0x49e8();return _0x9a06=function(_0x9a063c,_0x40f3e3){_0x9a063c=_0x9a063c-0x123;let _0x55b451=_0x49e8d9[_0x9a063c];return _0x55b451;},_0x9a06(_0x41e8cb,_0x44ab09);}const sendButLoc=async(_0x151338,_0x56cd7c,_0x33ce1f,_0xbff411,_0x1ecc85,_0x40a38d)=>{const _0xf018e3=_0x9a06;return buttonMessagesL={'contentText':_0x56cd7c,'footerText':_0x33ce1f,'buttons':_0x1ecc85,'headerType':0x6,'locationMessage':{'degreesLatitude':0x0,'degreesLongitude':0x0,'name':_0xf018e3(0x130),'address':_0xf018e3(0x12e),'jpegThumbnail':_0xbff411}},zeroyt7[_0xf018e3(0x127)](_0x151338,buttonMessagesL,buttonsMessage,{'quoted':_0x40a38d});};
const adyt = { 
"title": `Hallo ${pushname}`,
"body": `hy`, 
"mediaType": "2", 
"mediaUrl": "https://youtu.be/ilrhJV_QMIE", 
"thumbnail": fs.readFileSync('./arabotz/ara2.jpg')
}
const getRegisteredRandomId = () => {
return _registered[Math.floor(Math.random() * _registered.length)].id
}
const addRegisteredUser = (userid, sender, age, time, serials) => {
const obj = { id: userid, name: sender, age: age, time: time, serial: serials }
_registered.push(obj)
fs.writeFileSync('./database/registered.json', JSON.stringify(_registered))
}
const checkRegisteredUser = (sender) => {
let status = false
Object.keys(_registered).forEach((i) => {
if (_registered[i].id === sender) {
status = true
}
})
return status
}

const isRegistered = checkRegisteredUser(sender)

const sendButRegis = (id, text1, desc1, but = [], options = {}) => {
const buttonMessage = {
contentText: text1,
footerText: desc1,
buttons: but,
headerType: 1,
};
mario4647.sendMessage(
id,
buttonMessage,
MessageType.buttonsMessage,
options
);
};

const daftar1 = `Hai Kak ${pushname} 👋 Saya Ara Botz🍁 \n\nAnda Belum Terdaftar Di Dalam Database Ara Botz,Silahkan Register🍁`
const daftar2 = '```KLIK TOMBOL DI BAWAH INI YA,UNTUK REGISTER KE DALAM DATABASE ARA BOTZ🍁```'
const daftar3 = [{buttonId: `${prefix}verify`,buttonText: {displayText: `${pushname}`,},type: 1,},]

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

//===================《 FAKE FAKEAN  》=====================// 
        const fakestatus = (teks) => {
            mario4647.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": faketeks,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./arabotz/ara2.jpg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        mario4647.chatRead(from, "read")
        const fakegroup = (teks) => {
            mario4647.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": faketeks,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./arabotz/ara2.jpg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const ftrol = {
	key : {
                          participant : '0@s.whatsapp.net'
                        },
       message: {
                    orderMessage: {
                            itemCount : 123,
                            status: 1,
                            surface : 1,
                            message: `${tampilUcapan}\n${pushname}`, 
                            orderTitle: `Mario 4647🍁`,
                            thumbnail: zero,
                            sellerJid: '0@s.whatsapp.net' 
                          }
                        }
                      }
            const fvoc = {
	 key: { 
          fromMe: false,
	      participant: `0@s.whatsapp.net`, ...(from ? 
	 { remoteJid: "6289643739077-1613049930@g.us" } : {}) 
                },
	 message: { 
		"audioMessage": {
                 "mimetype":"audio/ogg; codecs=opus",
                 "seconds": "99999",
                 "ptt": "true"
                        }
	                  } 
                     }
            const fgif = {
	 key: { 
         fromMe: false,
	      participant: `0@s.whatsapp.net`, ...(from ? 
	 { remoteJid: "6289643739077-1613049930@g.us" } : {}) 
                },
	 message: { 
                 "videoMessage": { 
                 "title": `${tampilUcapan}\n${pushname}`,
                 "h": `${tampilUcapan}\n${pushname}`,
                 'duration': '99999', 
                 'gifPlayback': 'true', 
                 'caption': `${tampilUcapan}\n${pushname}`,
                 'jpegThumbnail': zero
                        }
                       }
	                  } 
             const finv = {
	"key": {
		"fromMe": false,
		"participant": "0@s.whatsapp.net",
		"remoteJid": "0@s.whatsapp.net"
	},
	"message": {
		"groupInviteMessage": {
			"groupJid": "6288213840883-1616169743@g.us",
			"inviteCode": `${tampilUcapan} ${pushname}`,
			"groupName": `${tampilUcapan} ${pushname}`, 
            "caption": `${tampilUcapan} ${pushname}`, 
            'jpegThumbnail': zero
		}
	}
}     
 const fvid = {
	 key: { 
          fromMe: false,
	      participant: `0@s.whatsapp.net`, ...(from ? 
	 { remoteJid: "6289643739077-1613049930@g.us" } : {}) 
                },
	 message: { 
                 "videoMessage": { 
                 "title": `Mario 4647`,
                 "h": `${tampilUcapan}\n${pushname}`,
                 'duration': '99999', 
                 'caption': `${tampilUcapan}\n${pushname}`,
                 'jpegThumbnail': zero
                        }
                       }
	                  }           
        
//===================《 CONNECTION 2  》=====================// 

        const sendStickerFromUrl = async(to, url) => {
                var names = Date.now() / 10000;
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, './stik' + names + '.png', async function () {
                    console.log('selesai');
                    let filess = './stik' + names + '.png'
                    let asw = './stik' + names + '.webp'
                    exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
                        let media = fs.readFileSync(asw)
                        mario4647.sendMessage(to, media, MessageType.sticker,{quoted:mek})
                        fs.unlinkSync(filess)
                        fs.unlinkSync(asw)
                    });
                });
            }
        const sendMediaURL = async(to, url, text="", mids=[]) =>{
                if(mids.length > 0){
                    text = normalizeMention(to, text, mids)
                }
                const fn = Date.now() / 10000;
                const filename = fn.toString()
                let mime = ""
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        mime = res.headers['content-type']
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, filename, async function () {
                    console.log('done');
                    let media = fs.readFileSync(filename)
                    let type = mime.split("/")[0]+"Message"
                    if(mime === "image/gif"){
                        type = MessageType.video
                        mime = Mimetype.gif
                    }
                    if(mime.split("/")[0] === "audio"){
                        mime = Mimetype.mp4Audio
                    }
                    mario4647.sendMessage(to, media, type, { quoted: ftrol, mimetype: mime, caption: text,contextInfo: {"mentionedJid": mids}})
                    
                    fs.unlinkSync(filename)
                });
            }   
            if (budy.includes("https://chat.whatsapp.com/")) {
if (!isGroup) return
if (!isAntiLink) return
if (isGroupAdmins) return
var kic = `${sender.split("@")[0]}@s.whatsapp.net`
reply(` *「 GROUP LINK DETECTOR 」*\n\nMAAF ${pushname} ANDA AKAN DI KICK KARENA TELAH MENGIRIM LINK GRUB`)
setTimeout(() => {
mario4647.groupRemove(from, [kic]).catch((e) => { reply(`BOT HARUS JADI ADMIN`) })
}, 0)
}

            if (budy.includes("Kontol")) {
if (!isGroup) return
if (!isAntiToxic) return
if (isGroupAdmins) return
var kic = `${sender.split("@")[0]}@s.whatsapp.net`
reply(` *「 TOXIC DETECTOR 」*\n\nMAAF ${pushname} ANDA AKAN DI KICK KARENA TELAH BERKATA KASAR DI GRUB`)
setTimeout(() => {
mario4647.groupRemove(from, [kic]).catch((e) => { reply(`BOT HARUS JADI ADMIN`) })
}, 0)
}

		if (budy.length > 3500) {
if (!isGroup) return
if (!isAntiVirtex) return
if (isGroupAdmins) return
reply('Tandai telah dibaca\n'.repeat(300))
reply(`「 *VIRTEX DETECTOR* 」\n\nKamu mengirimkan virtex, maaf kamu di kick dari group :(`)
console.log(color('[KICK]', 'red'), color('Received a virus text!', 'yellow'))
mario4647.groupRemove(from, [sender])
}     

if (isMuted){
             if (!isGroupAdmins && !isPremium) return
}

var premi = 'Gratisan'
             if (isPremium) {
             premi = 'Premium'
 }
                      

//===================《 CONNECTION 3  》=====================// 

		colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
		const isMedia = (type === 'imageMessage' || type === 'videoMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
      	if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mPRIVATE\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
      	//if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
     	if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mGRUB\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
      	//if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))

//===================《 MENU  》=====================// 

switch (command) {
case 'menu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`MENU\`\`\``
gam = fs.readFileSync('./arabotz/ara.jpg')
but = [
          { buttonId: `${prefix}simplemenu`, buttonText: { displayText: '♨SIMPLE MENU♨' }, type: 1 },
          { buttonId: `${prefix}allmenu`, buttonText: { displayText: '🍃ALL MENU🍃' }, type: 1 },
          { buttonId: `${prefix}groubsetting`, buttonText: { displayText: '⚙️GROUB SETTING⚙️' }, type: 1 }
        ]
        sendButImage(from, teks, `${tampilUcapan}\nHay ${pushname}👋\n\n\`\`\`TIME INFO🍃\`\`\`\n\n*${tampilUcapan}*\n*🕕 JAM : ${time}*\n*🕛 WIB : ${wib}*\n*🕐 WITA : ${wita}*\n*🕑 WIT : ${wit}*\n\n\`\`\`DAY INFO📆\`\`\`\n\n*📅 DAY : ${week}*\n*🗓️ WETON : ${weton}*\n*📆 TANGGAL : ${calender}*\n\n\`\`\`BROWSER INFO🌍\`\`\`\n\n*🌐 LANGUAGE : Java Script*\n*🔏 REST API : KurxXd*\n*🌍 LIB : Baileys*\n*♨ AUTOR : Mario 4647*\n*🍃 PREFIX :『> ${prefix} <』*\n\n\nS&K ${botname}\nHarus Di Patuhi, Kalau Tidak Di Kick\n\n1. Dilarang Toxic. \n2. Dilarang Spam Command.\n3. Dilarang Spam.\n4. Dilarang Telepon/VC.\n\nKalo Sudah Dipahami Rules Nya\nSilahkan Ketik ${prefix}menu\n© Mario 4647`, gam, but)
break
	
case 'allmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`BROWSER INFO🌍\`\`\`

*🌐 LANGUAGE : Java Script*
*🔏 REST API : KurxXd*
*🌍 LIB : Baileys*
*♨ AUTOR : Mario 4647*

\`\`\`BOT INFO🌸\`\`\`

*🍃 RUNTIME : ${runtime(process.uptime())}*
*🍃 BOT NAME : ${botname}*
*🍃 OWNER : ${ownername}*
*🍃 NO OWNER : ${owner}*
*🍃 CREATOR : ${creator}*
*🍃 PARTNER : ${partner}*
*🍃 RECODE : ${recode}*

\`\`\`USER INFO👤\`\`\`

*🪀USERNAME : ${pushname}*
*📞NO USER : ${sender.split("@")[0]}*
*🔖STATUS : ${premi}*


\`\`\`🍃ALL MENU🍃\`\`\`
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎
*${logo}GROUP MENU ${logo}*
🍃ツ${prefix}groubsetting
🍃ツ${prefix}linkgrup
🍃ツ${prefix}rulesgc
🍃ツ${prefix}promote
🍃ツ${prefix}demote
🍃ツ${prefix}kick
🍃ツ${prefix}tagme
 
*${logo}OWNER MENU ${logo}*
🍃ツ${prefix}bc
🍃ツ${prefix}report
🍃ツ${prefix}leave
🍃ツ${prefix}spam
🍃ツ${prefix}virtex
🍃ツ${prefix}virtex2
🍃ツ${prefix}setppwa
🍃ツ${prefix}setbio
🍃ツ${prefix}ban
🍃ツ${prefix}unban
🍃ツ${prefix}listban
🍃ツ${prefix}premium
🍃ツ${prefix}mute
🍃ツ${prefix}upswteks
🍃ツ${prefix}upswsticker
🍃ツ${prefix}upswaudio
🍃ツ${prefix}upswvidio
🍃ツ${prefix}upswimage
 
*${logo}PREMIUM MENU ${logo}*
🍃ツ${prefix}add
🍃ツ${prefix}setdecs
🍃ツ${prefix}setname
🍃ツ${prefix}setpp
🍃ツ${prefix}hidetag
🍃ツ${prefix}sharelock
🍃ツ${prefix}jadibot
🍃ツ${prefix}asupan
🍃ツ${prefix}asupancecan
🍃ツ${prefix}asupanhijaber
🍃ツ${prefix}asupansantuy
🍃ツ${prefix}asupanukhti
🍃ツ${prefix}asupanbocil
🍃ツ${prefix}asupanghea
🍃ツ${prefix}asupanrika

*${logo}SOUND MENU${logo}*
🍃ツ${prefix}sound1
🍃ツ${prefix}sound2
🍃ツ${prefix}sound3
🍃ツ${prefix}sound4
🍃ツ${prefix}sound5
🍃ツ${prefix}sound6
🍃ツ${prefix}sound7
🍃ツ${prefix}sound8
🍃ツ${prefix}sound9
🍃ツ${prefix}sound10
🍃ツ${prefix}sound11
🍃ツ${prefix}sound12
🍃ツ${prefix}sound13
🍃ツ${prefix}sound14
🍃ツ${prefix}sound15
🍃ツ${prefix}sound16
🍃ツ${prefix}sound17
🍃ツ${prefix}sound18
🍃ツ${prefix}sound19
🍃ツ${prefix}sound20
🍃ツ${prefix}sound21
🍃ツ${prefix}sound22
🍃ツ${prefix}sound23
🍃ツ${prefix}sound24
🍃ツ${prefix}sound25
🍃ツ${prefix}sound26
🍃ツ${prefix}sound27
🍃ツ${prefix}sound30
🍃ツ${prefix}sound31
🍃ツ${prefix}sound32
🍃ツ${prefix}sound33
🍃ツ${prefix}sound34
🍃ツ${prefix}sound35

*${logo}STICKER MENU ${logo}*
🍃ツ${prefix}attp
🍃ツ${prefix}patrick
🍃ツ${prefix}sticker
🍃ツ${prefix}tomp3
🍃ツ${prefix}tovideo
 
*${logo}DOWNLOAD MENU ${logo}*
🍃ツ${prefix}play
🍃ツ${prefix}ytsearch
🍃ツ${prefix}ytmp4
🍃ツ${prefix}tiktok
🍃ツ${prefix}tiktokmusic
🍃ツ${prefix}tiktokaudio
🍃ツ${prefix}pinterest
🍃ツ${prefix}igdl
🍃ツ${prefix}fbdl
🍃ツ${prefix}brainly
🍃ツ${prefix}lirik
🍃ツ${prefix}tiktoknown
🍃ツ${prefix}pinterrest
🍃ツ${prefix}spotifysearch
🍃ツ${prefix}playmp3
🍃ツ${prefix}playmp4
 
*${logo}ANIME MENU ${logo}*
🍃ツ${prefix}character
🍃ツ${prefix}manga
🍃ツ${prefix}anime
🍃ツ${prefix}kusonimesearch
🍃ツ${prefix}otakudesusearch
🍃ツ${prefix}nhentaisearch
🍃ツ${prefix}nekopoisearch
 
*${logo}INFO MENU ${logo}*
🍃ツ${prefix}kbbi
🍃ツ${prefix}jarak
🍃ツ${prefix}wikipedia
🍃ツ${prefix}translate
🍃ツ${prefix}jadwaltv
🍃ツ${prefix}infogempa
🍃ツ${prefix}cuaca
🍃ツ${prefix}covidindo
🍃ツ${prefix}covidglobal
 
*${logo}TEXT MENU ${logo}*
🍃ツ${prefix}quotes
🍃ツ${prefix}quotesanime
🍃ツ${prefix}quotesdilan
🍃ツ${prefix}quotesimage
🍃ツ${prefix}katabijak
🍃ツ${prefix}randomnama
 
*${logo}ISLAM MENU ${logo}*
🍃ツ${prefix}listsurah
🍃ツ${prefix}kisahnabi
🍃ツ${prefix}jadwalsholat
🍃ツ${prefix}asmaulhusna
🍃ツ${prefix}alquran
🍃ツ${prefix}alquranaudio
 
*${logo}SEARCH MENU ${logo}*
🍃ツ${prefix}gimage
🍃ツ${prefix}wallpapersearch
🍃ツ${prefix}playstore
🍃ツ${prefix}shopee
🍃ツ${prefix}google

*${logo}RANDOM MENU${logo}*
🍃ツ${prefix}tourl
🍃ツ${prefix}listvn
🍃ツ${prefix}addvn
🍃ツ${prefix}delvn
🍃ツ${prefix}listimage
🍃ツ${prefix}addimage
🍃ツ${prefix}delimage
🍃ツ${prefix}liststicker
🍃ツ${prefix}addsticker
🍃ツ${prefix}delsticker
🍃ツ${prefix}caripesan
🍃ツ${prefix}darkjokes
🍃ツ${prefix}meme
🍃ツ${prefix}apakah
🍃ツ${prefix}kapankah
🍃ツ${prefix}rate
🍃ツ${prefix}bisakah
🍃ツ${prefix}suit
🍃ツ${prefix}dadu
🍃ツ${prefix}semoji
 
*${logo}PRIMBON MENU ${logo}*
🍃ツ${prefix}artinama
🍃ツ${prefix}jodoh
🍃ツ${prefix}jadian
🍃ツ${prefix}tebakumur
 
*${logo}STALK MENU ${logo}*
🍃ツ${prefix}stalkig
🍃ツ${prefix}stalktiktok
🍃ツ${prefix}stalkgithub
 
*${logo}IMAGE MENU ${logo}*
🍃ツ${prefix}art
🍃ツ${prefix}bts
🍃ツ${prefix}exo
🍃ツ${prefix}elf
🍃ツ${prefix}loli
🍃ツ${prefix}neko
🍃ツ${prefix}waifu
🍃ツ${prefix}shota
🍃ツ${prefix}husbu
🍃ツ${prefix}sagiri
🍃ツ${prefix}shinobu
🍃ツ${prefix}megumin
🍃ツ${prefix}wallnime
🍃ツ${prefix}chiisaihentai
🍃ツ${prefix}trap
🍃ツ${prefix}blowjob
🍃ツ${prefix}yaoi
🍃ツ${prefix}ecchi
🍃ツ${prefix}hentai
🍃ツ${prefix}ahegao
🍃ツ${prefix}hololewd
🍃ツ${prefix}sideoppai
🍃ツ${prefix}animefeets
🍃ツ${prefix}animebooty
🍃ツ${prefix}animethighss
🍃ツ${prefix}animearmpits
🍃ツ${prefix}hentaifemdom
🍃ツ${prefix}lewdanimegirls
🍃ツ${prefix}biganimetiddies
🍃ツ${prefix}hentai4everyone
 
*${logo}CECAN MENU ${logo}*
🍃ツ${prefix}cecanvietnam
🍃ツ${prefix}cecanmalaysia
🍃ツ${prefix}cecankorea
🍃ツ${prefix}cecanindonesia
🍃ツ${prefix}cecanjapan
🍃ツ${prefix}cecanthailand
 
*${logo}GAME MENU ${logo}*
🍃ツ${prefix}tebakgambar
🍃ツ${prefix}slot
🍃ツ${prefix}tebakkimia
🍃ツ${prefix}tebaklirik
🍃ツ${prefix}tebakjenaka
🍃ツ${prefix}truth
🍃ツ${prefix}dare
🍃ツ${prefix}tebaktebakan
🍃ツ${prefix}tebakkalimat
🍃ツ${prefix}tembak
 
*${logo}BOT MENU${logo}*
🍃ツ${prefix}owner
🍃ツ${prefix}owner2
🍃ツ${prefix}info
🍃ツ${prefix}sewabot
🍃ツ${prefix}donasi
🍃ツ${prefix}runtime
🍃ツ${prefix}ping
🍃ツ${prefix}jadibot
🍃ツ${prefix}rulesbot

*${logo}MAKER MENU${logo}*
🍃ツ${prefix}nulis
🍃ツ${prefix}freefire
🍃ツ${prefix}pubg
🍃ツ${prefix}harrypotter
🍃ツ${prefix}pornhub
🍃ツ${prefix}phkomen
🍃ツ${prefix}ytkomen
🍃ツ${prefix}blackpink
🍃ツ${prefix}teks1917
🍃ツ${prefix}fakedonald

*${logo}NSFW MENU${logo}*
🍃ツ${prefix}yuri
🍃ツ${prefix}hentai
🍃ツ${prefix}anal
🍃ツ${prefix}lesbian
🍃ツ${prefix}eroneko
🍃ツ${prefix}bj
🍃ツ${prefix}kitsune
🍃ツ${prefix}pussy
🍃ツ${prefix}wallpaper
🍃ツ${prefix}neko2
🍃ツ${prefix}baka
🍃ツ${prefix}slap
🍃ツ${prefix}poke
🍃ツ${prefix}keta
🍃ツ${prefix}awoo
🍃ツ${prefix}blowjob
🍃ツ${prefix}megumin
🍃ツ${prefix}neko
🍃ツ${prefix}trapnime
🍃ツ${prefix}ass
🍃ツ${prefix}femdom
🍃ツ${prefix}hentaigif
🍃ツ${prefix}ahegao
🍃ツ${prefix}cum
🍃ツ${prefix}masturbation
🍃ツ${prefix}jahy
🍃ツ${prefix}orgy
🍃ツ${prefix}thigs
🍃ツ${prefix}panties
🍃ツ${prefix}foot
🍃ツ${prefix}gangbang
🍃ツ${prefix}bdsm
🍃ツ${prefix}ero
🍃ツ${prefix}glasses

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}

BOT INI MASIH BAKAL DI UPDATE TERUS
MAU REQUEST FITUR BARU?KETIK ${prefix}report *<ISI KATA KATA MU>*
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
case 'simplemenu':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
 stod = `${sender}`
 listMsg = {
 buttonText: 'ARA MENU🍃',
 footerText: '*© Mario 4647*',
 description: `${tampilUcapan}\nHai Kak @${stod.split('@')[0]}, Silahkan Pilih Menu Di Bawah Ini Ya🍃`,
 sections: [
                     {
                      "title": `ARA BOTZ🍃\nBy Mario 4647🍃`,
 rows: [
                          {
                              "title": "OWNER👤",
                              "rowId": `${prefix}owner`
                           },
                           {
                           	"title": "SHOP GAME💲",
                              "rowId": `${prefix}shopgame`
                           },
                           {
                              "title": "🍃GROUB MENU🍃",
                              "rowId": `${prefix}groubmenu`
                           },
                           {
                              "title": "🍃OWNER MENU🍃",
                              "rowId": `${prefix}ownermenu`
                           },
                           {
                              "title": "🍃PREMIUM MENU🍃",
                              "rowId": `${prefix}premiummenu`
                           },
                           {
                              "title": "🍃SOUND MENU🍃",
                              "rowId": `${prefix}soundmenu`
                           },
                           {
                              "title": "🍃BOT MENU🍃",
                              "rowId": `${prefix}botmenu`
                           },
                           {
                              "title": "🍃NSFW MENU🍃",
                              "rowId": `${prefix}nsfwmenu`
                           },
                           {
                              "title": "🍃CECAN MENU🍃",
                              "rowId": `${prefix}cecanmenu`
                           },
                           {
                              "title": "🍃RANDOM MENU🍃",
                              "rowId": `${prefix}randommenu`
                           },
                           {
                              "title": "🍃STICKER MENU🍃",
                              "rowId": `${prefix}stickermenu`
                           },
                           {
                              "title": "🍃DOWNLOAD MENU🍃",
                              "rowId": `${prefix}downloadmenu`
                           },
                           {
                              "title": "🍃ANIME MENU🍃",
                              "rowId": `${prefix}animemenu`
                           },
                           {
                              "title": "🍃INFO MENU🍃",
                              "rowId": `${prefix}infomenu`
                           },
                           {
                              "title": "🍃TEXT MENU🍃",
                              "rowId": `${prefix}textmenu`
                           },
                           {
                              "title": "🍃ISLAM MENU🍃",
                              "rowId": `${prefix}islammenu`
                           },
                           {
                              "title": "🍃PRIMBON MENU🍃",
                              "rowId": `${prefix}primbonmenu`
                           },
                           {
                              "title": "🍃STALK MENU🍃",
                              "rowId": `${prefix}stalkmenu`
                           },
                           {
                              "title": "🍃IMAGE MENU🍃",
                              "rowId": `${prefix}imagemenu`
                           },
                           {
                              "title": "🍃MAKER MENU🍃",
                              "rowId": `${prefix}makermenu`
                           }
                        ]
                     }],
 listType: 1
}
mario4647.sendMessage(from, listMsg, MessageType.listMessage, {contextInfo: { mentionedJid: [stod]},quoted:ftrol})
break
case 'shopgame':
stod = `${sender}`
listMsg = {
buttonText: 'SHOP MENU',
footerText: '*© Mario 4647*',
description: `Hai Kak @${stod.split('@')[0]}, Silahkan Pilih Menu Shop Di Bawah Ini Ya🍃`,
sections: [
                    {
                     "title": `ARA SHOP🍃\nBy Mario 4647🍃`,
rows: [
                         {
                             "title": "OWNER👤",
                             "rowId": `${prefix}owner`
                          },
                          {
                             "title": "UC PUBG💲",
                             "rowId": `${prefix}ucpubg`
                          },
                          {
                             "title": "DM FF💎",
                             "rowId": `${prefix}dmff`
                          },
                          {
                             "title": "DM ML💎",
                             "rowId": `${prefix}dmml`
                           }
                        ]
                     }],
 listType: 1
}
mario4647.sendMessage(from, listMsg, MessageType.listMessage, {contextInfo: { mentionedJid: [stod]},quoted:ftrol})
break
case 'groubsetting':
stod = `${sender}`
listMsg = {
buttonText: 'GROUB SETTING MENU',
footerText: '*© Mario 4647*',
description: `Hai Kak @${stod.split('@')[0]}, Silahkan Setting Grub Di Bawah Ini Ya🍃`,
sections: [
                    {
                     "title": `GROUB SETTING`,
rows: [
                         {
                             "title": "ANTILINK📛",
                             "rowId": `${prefix}antilink`
                          },
                          {
                             "title": "WELCOME🔖",
                             "rowId": `${prefix}welcome`
                          },
                          {
                             "title": "ANTIVIRTEX📑",
                             "rowId": `${prefix}antivirtex`
                          },
                          {
                          	"title": "NSFW🌸",
                             "rowId": `${prefix}nsfw`
                          },
                          {
                          	"title": "LINK GRUB📨",
                             "rowId": `${prefix}antivirtex`
                          },
                          {
                             "title": "GROUB OPEN/CLOSE♨",
                             "rowId": `${prefix}groub`
                           }
                        ]
                     }],
 listType: 1
}
mario4647.sendMessage(from, listMsg, MessageType.listMessage, {contextInfo: { mentionedJid: [stod]},quoted:ftrol})
break
case 'groubmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
	teks =
`\`\`\`🍃GROUB MENU🍃\`\`\`

‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎*${logo}GROUP MENU ${logo}*
🍃ツ${prefix}antilink
🍃ツ${prefix}welcome
🍃ツ${prefix}antivirtex
🍃ツ${prefix}nsfw
🍃ツ${prefix}group
🍃ツ${prefix}linkgrup
🍃ツ${prefix}rulesgc
🍃ツ${prefix}promote
🍃ツ${prefix}demote
🍃ツ${prefix}kick
🍃ツ${prefix}tagme

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
 case 'ownermenu':
if (!isOwner) return sticOwner(from)
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃OWNER MENU🍃\`\`\`

*${logo}OWNER MENU ${logo}*
🍃ツ${prefix}bc
🍃ツ${prefix}report
🍃ツ${prefix}leave
🍃ツ${prefix}spam
🍃ツ${prefix}virtex
🍃ツ${prefix}virtex2
🍃ツ${prefix}setppwa
🍃ツ${prefix}setbio
🍃ツ${prefix}ban
🍃ツ${prefix}unban
🍃ツ${prefix}listban
🍃ツ${prefix}premium
🍃ツ${prefix}mute
🍃ツ${prefix}upswteks
🍃ツ${prefix}upswsticker
🍃ツ${prefix}upswaudio
🍃ツ${prefix}upswvidio
🍃ツ${prefix}upswimage

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'premiummenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃PREMIUM MENU🍃\`\`\`

*${logo}PREMIUM MENU ${logo}*
🍃ツ${prefix}add
🍃ツ${prefix}setdecs
🍃ツ${prefix}setname
🍃ツ${prefix}setpp
🍃ツ${prefix}hidetag
🍃ツ${prefix}sharelock
🍃ツ${prefix}jadibot
🍃ツ${prefix}asupan
🍃ツ${prefix}asupancecan
🍃ツ${prefix}asupanhijaber
🍃ツ${prefix}asupansantuy
🍃ツ${prefix}asupanukhti
🍃ツ${prefix}asupanbocil
🍃ツ${prefix}asupanghea
🍃ツ${prefix}asupanrika

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'soundmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃SOUND MENU🍃\`\`\`

*${logo}SOUND MENU${logo}*
🍃ツ${prefix}sound1
🍃ツ${prefix}sound2
🍃ツ${prefix}sound3
🍃ツ${prefix}sound4
🍃ツ${prefix}sound5
🍃ツ${prefix}sound6
🍃ツ${prefix}sound7
🍃ツ${prefix}sound8
🍃ツ${prefix}sound9
🍃ツ${prefix}sound10
🍃ツ${prefix}sound11
🍃ツ${prefix}sound12
🍃ツ${prefix}sound13
🍃ツ${prefix}sound14
🍃ツ${prefix}sound15
🍃ツ${prefix}sound16
🍃ツ${prefix}sound17
🍃ツ${prefix}sound18
🍃ツ${prefix}sound19
🍃ツ${prefix}sound20
🍃ツ${prefix}sound21
🍃ツ${prefix}sound22
🍃ツ${prefix}sound23
🍃ツ${prefix}sound24
🍃ツ${prefix}sound25
🍃ツ${prefix}sound26
🍃ツ${prefix}sound27
🍃ツ${prefix}sound30
🍃ツ${prefix}sound31
🍃ツ${prefix}sound32
🍃ツ${prefix}sound33
🍃ツ${prefix}sound34
🍃ツ${prefix}sound35

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'stickermenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃STICKER MENU🍃\`\`\`

*${logo}STICKER MENU ${logo}*
🍃ツ${prefix}attp
🍃ツ${prefix}patrick
🍃ツ${prefix}sticker
🍃ツ${prefix}tomp3
🍃ツ${prefix}tovidio

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
 
 case 'downloadmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃DOWNLOAD MENU🍃\`\`\`

*${logo}DOWNLOAD MENU ${logo}*
🍃ツ${prefix}play
🍃ツ${prefix}ytsearch
🍃ツ${prefix}ytmp4
🍃ツ${prefix}tiktok
🍃ツ${prefix}tiktokmusic
🍃ツ${prefix}tiktokaudio
🍃ツ${prefix}pinterest
🍃ツ${prefix}igdl
🍃ツ${prefix}fbdl
🍃ツ${prefix}brainly
🍃ツ${prefix}lirik
🍃ツ${prefix}tiktoknown
🍃ツ${prefix}pinterrest
🍃ツ${prefix}spotifysearch
🍃ツ${prefix}playmp3
🍃ツ${prefix}playmp4

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'animemenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃ANIME MENU🍃\`\`\`

*${logo}ANIME MENU ${logo}*
🍃ツ${prefix}character
🍃ツ${prefix}manga
🍃ツ${prefix}anime
🍃ツ${prefix}kusonimesearch
🍃ツ${prefix}otakudesusearch
🍃ツ${prefix}nhentaisearch
🍃ツ${prefix}nekopoisearch
 
*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
 
case 'infomenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃INFO MENU🍃\`\`\`

*${logo}INFO MENU ${logo}*
🍃ツ${prefix}kbbi
🍃ツ${prefix}jarak
🍃ツ${prefix}wikipedia
🍃ツ${prefix}translate
🍃ツ${prefix}jadwaltv
🍃ツ${prefix}infogempa
🍃ツ${prefix}cuaca
🍃ツ${prefix}covidindo
🍃ツ${prefix}covidglobal

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

 case 'textmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃TEXT MENU🍃\`\`\`

*${logo}TEXT MENU ${logo}*
🍃ツ${prefix}quotes
🍃ツ${prefix}quotesanime
🍃ツ${prefix}quotesdilan
🍃ツ${prefix}quotesimage
🍃ツ${prefix}katabijak
🍃ツ${prefix}randomnama

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

 case 'islammenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃ISLAM MENU\`\`\`

*${logo}ISLAM MENU ${logo}*
🍃ツ${prefix}listsurah
🍃ツ${prefix}kisahnabi
🍃ツ${prefix}jadwalsholat
🍃ツ${prefix}asmaulhusna
🍃ツ${prefix}alquran
🍃ツ${prefix}alquranaudio

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'searchmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃SEARCH MENU🍃\`\`\`

*${logo}SEARCH MENU ${logo}*
🍃ツ${prefix}gimage
🍃ツ${prefix}wallpapersearch
🍃ツ${prefix}playstore
🍃ツ${prefix}shopee
🍃ツ${prefix}google

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'randommenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃RANDOM MENU🍃\`\`\`

*${logo}RANDOM MENU${logo}*
🍃ツ${prefix}tourl
🍃ツ${prefix}listvn
🍃ツ${prefix}addvn
🍃ツ${prefix}delvn
🍃ツ${prefix}listimage
🍃ツ${prefix}addimage
🍃ツ${prefix}delimage
🍃ツ${prefix}liststicker
🍃ツ${prefix}addsticker
🍃ツ${prefix}delsticker
🍃ツ${prefix}caripesan
🍃ツ${prefix}darkjokes
🍃ツ${prefix}meme
🍃ツ${prefix}apakah
🍃ツ${prefix}kapankah
🍃ツ${prefix}rate
🍃ツ${prefix}bisakah
🍃ツ${prefix}suit
🍃ツ${prefix}dadu
🍃ツ${prefix}semoji

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'primbonmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃PRIMBON MENU🍃\`\`\`

*${logo}PRIMBON MENU ${logo}*
🍃ツ${prefix}artinama
🍃ツ${prefix}jodoh
🍃ツ${prefix}jadian
🍃ツ${prefix}tebakumur

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'stalkmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃STALK MENU🍃\`\`\`

*${logo}STALK MENU ${logo}*
🍃ツ${prefix}stalkig
🍃ツ${prefix}stalktiktok
🍃ツ${prefix}stalkgithub

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'imagemenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃IMAGE MENU🍃\`\`\`

*${logo}IMAGE MENU ${logo}*
🍃ツ${prefix}art
🍃ツ${prefix}bts
🍃ツ${prefix}exo
🍃ツ${prefix}elf
🍃ツ${prefix}loli
🍃ツ${prefix}neko
🍃ツ${prefix}waifu
🍃ツ${prefix}shota
🍃ツ${prefix}husbu
🍃ツ${prefix}sagiri
🍃ツ${prefix}shinobu
🍃ツ${prefix}megumin
🍃ツ${prefix}wallnime
🍃ツ${prefix}chiisaihentai
🍃ツ${prefix}trap
🍃ツ${prefix}blowjob
🍃ツ${prefix}yaoi
🍃ツ${prefix}ecchi
🍃ツ${prefix}hentai
🍃ツ${prefix}ahegao
🍃ツ${prefix}hololewd
🍃ツ${prefix}sideoppai
🍃ツ${prefix}animefeets
🍃ツ${prefix}animebooty
🍃ツ${prefix}animethighss
🍃ツ${prefix}animearmpits
🍃ツ${prefix}hentaifemdom
🍃ツ${prefix}lewdanimegirls
🍃ツ${prefix}biganimetiddies
🍃ツ${prefix}hentai4everyone

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
 
case 'cecanmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃CECAN MENU🍃\`\`\`

*${logo}CECAN MENU ${logo}*
🍃ツ${prefix}cecanvietnam
🍃ツ${prefix}cecanmalaysia
🍃ツ${prefix}cecankorea
🍃ツ${prefix}cecanindonesia
🍃ツ${prefix}cecanjapan
🍃ツ${prefix}cecanthailand

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'gamemenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃GAME MENU🍃\`\`\`

*${logo}GAME MENU ${logo}*
🍃ツ${prefix}tebakgambar
🍃ツ${prefix}slot
🍃ツ${prefix}tebakkimia
🍃ツ${prefix}tebaklirik
🍃ツ${prefix}tebakjenaka
🍃ツ${prefix}truth
🍃ツ${prefix}dare
🍃ツ${prefix}tebaktebakan
🍃ツ${prefix}tebakkalimat
🍃ツ${prefix}tembak
 
*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
 
case 'botmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃BOT MENU🍃\`\`\`

*${logo}BOT MENU${logo}*
🍃ツ${prefix}owner
🍃ツ${prefix}owner2
🍃ツ${prefix}info
🍃ツ${prefix}sewabot
🍃ツ${prefix}donasi
🍃ツ${prefix}runtime
🍃ツ${prefix}ping
🍃ツ${prefix}jadibot
🍃ツ${prefix}rulesbot

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'makermenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
	teks =
`\`\`\`🍃MAKER MENU🍃\`\`\`

*${logo}MAKER MENU${logo}*
🍃ツ${prefix}nulis
🍃ツ${prefix}freefire
🍃ツ${prefix}pubg
🍃ツ${prefix}harrypotter
🍃ツ${prefix}pornhub
🍃ツ${prefix}phkomen
🍃ツ${prefix}ytkomen
🍃ツ${prefix}blackpink
🍃ツ${prefix}teks1917
🍃ツ${prefix}fakedonald

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break

case 'nsfwmenu':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`*NSFW BELUM AKTIF,SILAHKAN AKTIFKAN DI GRUB*`)
	teks =
`\`\`\`🍃NSFW MENU🍃\`\`\`

*${logo}NSFW MENU${logo}*
🍃ツ${prefix}yuri
🍃ツ${prefix}hentai
🍃ツ${prefix}anal
🍃ツ${prefix}lesbian
🍃ツ${prefix}eroneko
🍃ツ${prefix}bj
🍃ツ${prefix}kitsune
🍃ツ${prefix}pussy
🍃ツ${prefix}wallpaper
🍃ツ${prefix}neko2
🍃ツ${prefix}baka
🍃ツ${prefix}slap
🍃ツ${prefix}poke
🍃ツ${prefix}keta
🍃ツ${prefix}awoo
🍃ツ${prefix}blowjob
🍃ツ${prefix}megumin
🍃ツ${prefix}neko
🍃ツ${prefix}trapnime
🍃ツ${prefix}ass
🍃ツ${prefix}femdom
🍃ツ${prefix}hentaigif
🍃ツ${prefix}ahegao
🍃ツ${prefix}cum
🍃ツ${prefix}masturbation
🍃ツ${prefix}jahy
🍃ツ${prefix}orgy
🍃ツ${prefix}thigs
🍃ツ${prefix}panties
🍃ツ${prefix}foot
🍃ツ${prefix}gangbang
🍃ツ${prefix}bdsm
🍃ツ${prefix}ero
🍃ツ${prefix}glasses

*❖${logo}TQTO${logo}❖*
*❒* Mario 4647
*❒* Lipi
*❒* Viona
*❒* WhatsApp
*❒* ${ownername}
`
var imgs = await mario4647.prepareMessage('0@c.us', tamnel, image, { thumbnail: tamnel })
            var imgCatalog = imgs.message.imageMessage
            var ctlg = await mario4647.prepareMessageFromContent(from, {
                "productMessage": {
                    "product": {
                        "productImage": imgCatalog,
                        "productId": "4457725420906655",
                        "title": `メMario 4647`,
                        "description": teks,
                        "footerText": `メMario 4647`,
                        "currencyCode": "IDR",
                        "priceAmount1000": "100000000",
                        "productImageCount": 1,
                        "firstImageId": 1,
                        "salePriceAmount1000": "35000000",
                        "retailerId": `ARA BOTZ🍃`,
                        "url": "Mario 4647"
                    },
                    "businessOwnerJid": "6285730012621@s.whatsapp.net",
                }
            }, { quoted: fgif, mimetype: 'image/jpeg' })
            mario4647.relayWAMessage(ctlg)
            break
            
//=============《 FITUR GROUP 》==============//

case 'welcome' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: finv})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
but = [
{ buttonId: '!welcomeon', buttonText: { displayText: 'ON🔖' }, type: 1 },
{ buttonId: '!welcomeoff', buttonText: { displayText: 'OFF🔖' }, type: 1 }
]
sendButton(from, "Silahkan pilih untuk welcome group", faketeks, but, mek)
break
case 'welcomeon' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (isWelkom) return reply('welcome sudah on')
_welkom.push(from)
fs.writeFileSync('./database/welcome.json', JSON.stringify(_antilink))
reply(`\`\`\`✓Sukses mengaktifkan fitur welcome di group\`\`\` *${groupMetadata.subject}*`)
break
case 'welcomeoff' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isWelkom) return reply('welcome sudah off sebelumnya')
_welkom.splice(from, 1)
fs.writeFileSync('./database/welcome.json', JSON.stringify(_antilink))
reply(`\`\`\`✓Sukses menonaktifkan fitur welcome di group\`\`\` *${groupMetadata.subject}*`)
break
case 'antilink' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
but = [
{ buttonId: '!antilinkon', buttonText: { displayText: 'ON🔖' }, type: 1 },
{ buttonId: '!antilinkoff', buttonText: { displayText: 'OFF🔖' }, type: 1 }
]
sendButton(from, "Silahkan pilih untuk antilink group", faketeks, but, mek)
break
case 'antilinkon' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (isAntiLink) return reply('anti link sudah on')
_antilink.push(from)
fs.writeFileSync('./database/antilink.json', JSON.stringify(_antilink))
reply(`\`\`\`✓Sukses mengaktifkan fitur anti link di group\`\`\` *${groupMetadata.subject}*`)
break
case 'antilinkoff' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (!isAntiLink) return reply('anti link sudah off sebelumnya')
_antilink.splice(from, 1)
fs.writeFileSync('./database/antilink.json', JSON.stringify(_antilink))
reply(`\`\`\`✓Sukses menonaktifkan fitur anti link di group\`\`\` *${groupMetadata.subject}*`)
break
case 'antitoxic' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
but = [
{ buttonId: '!antitoxicon', buttonText: { displayText: 'ON🔖' }, type: 1 },
{ buttonId: '!antitoxicoff', buttonText: { displayText: 'OFF🔖' }, type: 1 }
]
sendButton(from, "Silahkan pilih untuk antitoxic group", faketeks, but, mek)
break
case 'antitoxicon' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (isAntiLink) return reply('antitoxic sudah on')
_antilink.push(from)
fs.writeFileSync('./database/antitoxic.json', JSON.stringify(_antilink))
reply(`\`\`\`✓Sukses mengaktifkan fitur antitoxic di group\`\`\` *${groupMetadata.subject}*`)
break
case 'antitoxicoff' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (!isAntiLink) return reply('antitoxic sudah off sebelumnya')
_antilink.splice(from, 1)
fs.writeFileSync('./database/antitoxic.json', JSON.stringify(_antilink))
reply(`\`\`\`✓Sukses menonaktifkan fitur antitoxic di group\`\`\` *${groupMetadata.subject}*`)
break
case 'antivirtex' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
but = [
{ buttonId: '!antivirtexon', buttonText: { displayText: 'ON🔖' }, type: 1 },
{ buttonId: '!antivirtexoff', buttonText: { displayText: 'OFF🔖' }, type: 1 }
]
sendButton(from, "Silahkan pilih untuk antivirtex group", faketeks, but, mek)
break
case 'antivirtexon' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (isAntiVirtex) return reply('anti virtex group sudah aktif sebelumnya')
_antivirtex.push(from)
fs.writeFileSync('./database/antivirtex.json', JSON.stringify(_antivirtex))
reply(`\`\`\`Sukses mengaktifkan mode anti virtex di group\`\`\` *${groupMetadata.subject}*`)
break
case 'antivirtexoff' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (!isAntiVirtex) return reply('Mode anti virtex sudah nonaktif sebelumnya')
_antivirtex.splice(from, 1)
fs.writeFileSync('./database/antivirtex.json', JSON.stringify(_antivirtex))
reply(`\`\`\`✓Sukes menonaktifkan mode anti virtex di group\`\`\` *${groupMetadata.subject}*`)
break
case 'group' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroupAdmins) return sticAdmin(from)
if (!isGroup) return reply(mess.only.group)
if (!isBotGroupAdmins) return reply("Bot Bukan Admin")
but = [
{ buttonId: '!groupbuka', buttonText: { displayText: 'OPEN🔖' }, type: 1 },
{ buttonId: '!grouptutup', buttonText: { displayText: 'CLOSE🔖' }, type: 1 }
]
sendButton(from, "Silahkan pilih untuk buka/tutup group", faketeks, but, mek)
break
case 'groupbuka' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
reply(`\`\`\`✓Sukses Membuka Group\`\`\` *${groupMetadata.subject}*`)
mario4647.groupSettingChange(from, GroupSettingChange.messageSend, false)
break
case 'grouptutup' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
reply(`\`\`\`✓Sukses Menutup Group\`\`\` *${groupMetadata.subject}*`)
mario4647.groupSettingChange(from, GroupSettingChange.messageSend, true)
break
case 'linkgrup' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isBotGroupAdmins) return sticNotAdmin(from)
linkgc = await mario4647.groupInviteCode(from)
yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group *${groupName}*`
mario4647.sendMessage(from, yeh, text, { quoted: ftrol })
break
case 'promote' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di jadi admin!')
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
if (mentioned.length > 1) {
teks = 'Perintah di terima, anda menjdi admin :\n'
for (let _ of mentioned) {
teks += `@${_.split('@')[0]}\n`
}
mentions(teks, mentioned, true)
mario4647.groupMakeAdmin(from, mentioned)
} else {
mentions(`Perintah di terima, @${mentioned[0].split('@')[0]} Kamu Menjadi Admin Di Group *${groupMetadata.subject}*`, mentioned, true)
mario4647.groupMakeAdmin(from, mentioned)
}
break
case 'demote' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tidak jadi admin!')
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
if (mentioned.length > 1) {
teks = 'Perintah di terima, anda tidak menjadi admin :\n'
for (let _ of mentioned) {
teks += `@${_.split('@')[0]}\n`
}
mentions(teks, mentioned, true)
mario4647.groupDemoteAdmin(from, mentioned)
} else {
mentions(`Perintah di terima, Menurunkan : @${mentioned[0].split('@')[0]} Menjadi Member`, mentioned, true)
mario4647.groupDemoteAdmin(from, mentioned)
}
break
case 'add':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return reply(mess.only.bodmin)
if (args.length < 1) return reply('Nomer Yg Mau Di Add Mana ?')
if (args[0].startsWith('08')) return reply('Gunakan Kode Negara Gan')
try {
num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
zero.groupAdd(from, [num])
} catch (e) {
console.log('Error :', e)
reply('𝐆𝐚𝐠𝐚𝐥 𝐌𝐞𝐧𝐚𝐦𝐛𝐚𝐡𝐤𝐚𝐧 𝐓𝐚𝐫𝐠𝐞𝐭, 𝐌𝐮𝐧𝐠𝐤𝐢𝐧 𝐊𝐚𝐫𝐞𝐧𝐚 𝐃𝐢 𝐏𝐫𝐢𝐯𝐚𝐭𝐞!')
}
break
case 'tagme':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
var nomqm = mek.participant
tagu = `@${nomqm.split('@s.whatsapp.net')[0]}`
mario4647.sendMessage(from, tagu, text, { quoted: ftrol, contextInfo: { forwardingScore: 508, isForwarded: true, mentionedJid: [nomqm]}})
break
case 'kick' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isOwner) return sticOwner(from)
if (!isBotGroupAdmins) return sticNotAdmin(from)
if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!')
mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
if (mentioned.length > 1) {
teks = 'Perintah Di Terima, Mengeluarkan :\n'
for (let _ of mentioned) {
teks += `@${_.split('@')[0]}\n`
}
mentions(teks, mentioned, true)
mario4647.groupRemove(from, mentioned)
} else {
mentions(`Perintah Di Terima, Mengeluarkan : @${mentioned[0].split('@')[0]}`, mentioned, true)
mario4647.groupRemove(from, mentioned)
}
break
case 'tag':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (args.length < 1) return reply(`Nomernya Mana ?\nContoh ${prefix}tag 62xnxx`)
var nomqm = `${body.slice(5)}@s.whatsapp.net`
tagq = `@${nomqm.split('@')[0]}` 
mario4647.sendMessage(from, tagq, text, { quoted: ftrol, contextInfo: { forwardingScore: 508, isForwarded: true, mentionedJid: [nomqm]}})
break
case 'tagall':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
members_id = []
teks = (args.length > 1) ? args.join(' ').trim() : ''
teks += '\n\n'
for (let mem of groupMembers) {
teks += `• @${mem.jid.split('@')[0]}\n`
members_id.push(mem.jid)
}
mentions(teks, members_id, true)
break
case 'setname':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return reply(mess.only.bodmin)
zero.groupUpdateSubject(from, `${body.slice(9)}`)
mario4647.sendMessage(from, `\`\`\`𝐒𝐮𝐤𝐬𝐞𝐬 𝐌𝐞𝐧𝐠𝐠𝐚𝐧𝐭𝐢 𝐍𝐚𝐦𝐚 𝐆𝐫𝐨𝐮𝐩 𝐌𝐞𝐧𝐣𝐚𝐝𝐢\`\`\` *${body.slice(9)}*`, text, { quoted: ftrol })
break
case 'setdesc':
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return reply(mess.only.bodmin)
zero.groupUpdateDescription(from, `${body.slice(9)}`)
mario4647.sendMessage(from, `\`\`\𝐒𝐮𝐤𝐬𝐞𝐬 𝐌𝐞𝐧𝐠𝐠𝐚𝐧𝐭𝐢 𝐃𝐞𝐬𝐤𝐫𝐢𝐩𝐬𝐢 𝐆𝐫𝐨𝐮𝐩\`\`\` *${groupMetadata.subject}* Menjadi: *${body.slice(9)}*`, text, { quoted: ftrol })
break
case 'setpp':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
media = await mario4647.downloadAndSaveMediaMessage(mek, './database/media_user')
await mario4647.updateProfilePicture(from, media)
sticWait(from)
reply(`\`\`\`✓Sukses Mengganti Profil Group\`\`\` *${groupMetadata.subject}*`)
break
case 'hidetag':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
if (!isGroup) return reply(mess.only.group)
if (!isGroupAdmins) return sticAdmin(from)
if (!isBotGroupAdmins) return reply(mess.only.Badmin)
var value = body.slice(9)
var group = await mario4647.groupMetadata(from)
var member = group['participants']
var mem = []
member.map(async adm => {
mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
var options = {
text: value,
contextInfo: { mentionedJid: mem },
quoted: ftrol
}
mario4647.sendMessage(from, options, text)
break
case 'listadmin':
if (!isGroup) return replyWithFakeLink(mess.only.group)
teks = `Name Gc : ${groupMetadata.subject}\n*List of Admin : ${groupAdmins.length}*\n\n`
for (let admon of groupAdmins) {
teks += `• @${admon.split('@')[0]}\n`
}
mentions(teks, groupAdmins, true)
break
case 'nsfw':
if (!isGroup) return reply(mess.only.group)
if (!isOwner) return sticOwner(from)
but = [
{ buttonId: '!nsfwon', buttonText: { displayText: 'ON🔖' }, type: 1 },
{ buttonId: '!nsfwoff', buttonText: { displayText: 'OFF🔖' }, type: 1 }
]
sendButton(from, "Silahkan Pilih Untuk Nsfw Group", faketeks, but, mek)
break
case 'nsfwon':
if (!isGroup) return reply(mess.only.group)
if (!isOwner) return sticOwner(from)
if (isNsfw) return reply('Sudah Aktif Kak')
nsfww.push(from)
fs.writeFileSync('./database/nsfww.json', JSON.stringify(nsfww))
reply('Sukses mengaktifkan fitur nsfw')
break
case 'nsfwoff':
if (!isGroup) return reply(mess.only.group)
if (!isOwner) return sticOwner(from)
if (!isNsfw) return reply('Sudah Mati Kak')
var ini = nsfww.indexOf(from)
nsfww.splice(ini, 1)
fs.writeFileSync('./database/nsfww.json', JSON.stringify(nsfww))
reply('Sukses menonaktifkan fitur nsfw')
break
case 'resetlinkgc':
         case 'resetlinkgroup':
         case 'revoke':
     case 'resetlink':
         if (!isGroup) return reply(mess.only.group)
         if (!isGroupAdmins) return sticAdmin(from)
                   if (!isBotGroupAdmins) return reply(mess.only.Badmin)
          json = ['action', 'inviteReset', from]
         mario4647.query({json, expect200: true})
          reply('Sukses Mereset Link Group')
         break
//==============《 SOUND MENU 》==============//
case 'sound1':
      case 'sound2':
      case 'sound3':
      case 'sound4':
      case 'sound5':
      case 'sound6':
      case 'sound7':
      case 'sound8':
      case 'sound9':
      case 'sound10':
      case 'sound11':
      case 'sound12':
      case 'sound13':
      case 'sound14':
      case 'sound15':
      case 'sound16':
      case 'sound17':
      case 'sound18':
      case 'sound19':
      case 'sound20':
      case 'sound21':
      case 'sound22':
      case 'sound23':
      case 'sound24':
      case 'sound25':
      case 'sound26':
      case 'sound27':
      case 'sound28':
      case 'sound29':
      case 'sound30':
      case 'sound31':
      case 'sound32':
      case 'sound33':
      case 'sound34':
      case 'sound35':
      case 'sound36':
      case 'sound37':
      case 'sound38':
      case 'sound39':
      case 'sound40':
      case 'sound41':
      case 'sound42':
      case 'sound43':
      case 'sound44':
      case 'sound45':
      case 'sound46':
      case 'sound47':
      case 'sound48':
      case 'sound49':
      case 'sound50':
      case 'sound51':
      case 'sound52':
      case 'sound53':
      case 'sound54':
      case 'sound55':
      case 'sound56':
      case 'sound57':
      case 'sound58':
      case 'sound59':
      case 'sound60':
      case 'sound61':
      case 'sound62':
      case 'sound63':
      case 'sound64':
      case 'sound65':
      case 'sound66':
      case 'sound67':
      case 'sound68':
      case 'sound69':
      case 'sound70':
      
      omkeh = await getBuffer(`https://hansxd.nasihosting.com/sound/${command}.mp3`)
      mario4647.sendMessage(from, omkeh, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true })
          break
          case 'sound71':
      case 'sound71':
      case 'sound72':
      case 'sound73':
      case 'sound74':
      case 'sound75':
      
      omkeh = await getBuffer(`https://ojankyaa.000webhostapp.com/sound/${command}.mp3`)
      mario4647.sendMessage(from, omkeh, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true })
          break         
          
          case 'kodenuklir':
res = await mario4647.prepareMessageFromContent(from,{
					"buttonsMessage": {
						"text": "",
				"imageMessage": {
						"url": "https://mmg.whatsapp.net/d/f/AkN2CkuI0Ra5pjBRiJDaW0CC-Wd9HUPFI-TnTDW3rkYy.enc",
						"mimetype": "image/jpeg",
						"fileSha256": "090qnz/i+SxRxHNUztQwjfxmL7XAMiAyL6Kw7aBMIHw=",
						"fileLength": "44782",
						"height": 740,
						"width": 640,
						"mediaKey": "euwj3NlkbZ+B0E67HIzwb8isEogbcPogdFJCllUbdjA=",
						"fileEncSha256": "aDzE4IikU5jH87beKM2eUtPgnTwQIqbNGYsMCoYKnsg=",
						"mediaKeyTimestamp": "1633022751"
					 },
						"contentText": `📸YAH SUKA 2D 📸
▬▭▬▭▬▭▬▭▬▬▭▬▭
Hai ${pushname}
▬▭▬▭▬▭▬▭▬▬▭▬▭
HELLO !!!
Note : EASY MODE = Sange, Biasa Aja, Mental Lemah :v
==============================
MEDIUM MODE = Bisa bikin sange, Lumayan nyesek, Rasanya pengen coli teros, Mental Batu
==============================
HARD MODE = Menyebabkan amnesia, insomnia, hipotermia, kejang", serangan jantung, diare, pendarahan hebat, buang air tidak terkendali, rasa ingin baku hantam, frustasi, depresi, emosi tidak tertahan kan, sakit hati (ambyar), Mental Baja
==============================
▬▭▬▭▬▭▬▭▬▬▭▬▭`,
						"footerText": "Mario 4647",
						"buttons": [
							{
								"buttonId": "HAIKAL",
								"buttonText": {
									"displayText": ` - EASY MODE
▬▭▬▭▬▭▬▭▬▬▭▬▭						
Hai ${pushname}
▬▭▬▭▬▭▬▭▬▬▭▬▭
Easy Mode :
• https://nhentai.net/g/316755/
• https://nhentai.net/g/316596/
• https://nhentai.net/g/311850/
• https://nhentai.net/g/315578/
• https://nhentai.net/g/315488/
• https://nhentai.net/g/315406/
• https://nhentai.net/g/315344/
• https://nhentai.net/g/315323/
• https://nhentai.net/g/315136/
• https://nhentai.net/g/315099/
▬▭▬▭▬▭▬▭▬▬▭▬▭`,
								},
								"type": "RESPONSE"
							},
							{
								"buttonId": "HAIKAL",
								"buttonText": {
									"displayText": ` - MEDIUM MODE -
▬▭▬▭▬▭▬▭▬▬▭▬▭						
Hai ${pushname}
▬▭▬▭▬▭▬▭▬▬▭▬▭
Medium Mode :
• https://nhentai.net/g/316867/
• https://nhentai.net/g/316869/
• https://nhentai.net/g/316785/
• https://nhentai.net/g/316763/51/
• https://nhentai.net/g/316445/
• https://nhentai.net/g/316250/
• https://nhentai.net/g/311283/
• https://nhentai.net/g/265671/
• https://nhentai.net/g/312127/
• https://nhentai.net/g/311560/
▬▭▬▭▬▭▬▭▬▬▭▬▭`,
								},
								"type": "RESPONSE"
							},
							{
								"buttonId": "HAIKAL",
								"buttonText": {
									"displayText": ` - HARD MODE -
▬▭▬▭▬▭▬▭▬▬▭▬▭						
Hai ${pushname}
▬▭▬▭▬▭▬▭▬▬▭▬▭
Hard Mode :
• https://nhentai.net/g/316820/
• https://nhentai.net/g/316481/
• https://nhentai.net/g/316430/
• https://nhentai.net/g/276347/
• https://nhentai.net/g/196329/
• https://nhentai.net/g/304543/
• https://nhentai.net/g/295295/
• https://nhentai.net/g/311262/
• https://nhentai.net/g/311882/
• https://nhentai.net/g/312180/

══{*BONUS COK*}══
https://nhentai.net/g/271890/
https://nhentai.net/g/272057/
https://nhentai.net/g/272173/
https://nhentai.net/g/272182/
https://nhentai.net/g/272196/
https://nhentai.net/g/272197/
https://nhentai.net/g/272259/
https://nhentai.net/g/272276/
https://nhentai.net/g/272290/
https://nhentai.net/g/272377/
-
https://nhentai.net/g/272390/
https://nhentai.net/g/272512/
https://nhentai.net/g/271245/
https://nhentai.net/g/271056/
https://nhentai.net/g/270809/
https://nhentai.net/g/269653/
https://nhentai.net/g/266088/
https://nhentai.net/g/264980/
https://nhentai.net/g/262215/
https://nhentai.net/g/260433/
-
https://nhentai.net/g/260146/
https://nhentai.net/g/256738/
https://nhentai.net/g/272425/
https://nhentai.net/g/272352/
https://nhentai.net/g/272045/
https://nhentai.net/g/272015/
https://nhentai.net/g/271993/
https://nhentai.net/g/271924/
https://nhentai.net/g/271905/
https://nhentai.net/g/271797/
-
https://nhentai.net/g/271760/
https://nhentai.net/g/271717/
https://nhentai.net/g/271726/
https://nhentai.net/g/271667/
https://nhentai.net/g/267352/
https://nhentai.net/g/152968/
https://nhentai.net/g/238876/
https://nhentai.net/g/116395/
https://nhentai.net/g/84809/
https://nhentai.net/g/211656/
-
https://nhentai.net/g/272117/
https://nhentai.net/g/188721/
https://nhentai.net/g/266402/
https://nhentai.net/g/238876/
▬▭▬▭▬▭▬▭▬▬▭▬▭`,
								},
								"type": "RESPONSE"
							}
						],
						"headerType": "IMAGE"
					}
}, {quoted:ftrol})
mario4647.relayWAMessage(res)
break
case 'faktaunik':
case 'katabijak':
case 'pantun':
case 'bucin':
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/random/${command}?apikey=KemolX7`)
                   titid = get_result.result
                   sendButMessage(from, titid, `Klik Untuk Ke Quotes Selanjutnya`, [
          {
            buttonId: `${prefix + command}`,
            buttonText: {
              displayText: `➡️ NEXT`,
            },
            type: 1,
          },]);
        break
        case 'pem':{
const buttons = [{buttonId: `!000`, buttonText: {displayText: '\nMau Banget><'}, type: 1},{buttonId: `!0000`, buttonText: {displayText: '\nIdihhh Najis'}, type: 1},{buttonId: `!00000`, buttonText: {displayText: '\nMaaf Kamu Jelek'}, type: 1}]
const buttonMessage = {
  headerType: "IMAGE",
  contentText: `Kak Aku Suka Kamu Loh:>\nMau Gak Kamu Jadi Pacar Aku:>`,
  footerText: `Mwehehehehehe`,
  buttons: buttons,
  headerType: 1
  }  
  mario4647.sendMessage(from, buttonMessage, MessageType.buttonsMessage)
  }
  break
  case '000':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
  reply('Love You Tooo Kak><')
  break
  case '0000':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
  reply('Apa Ga Mau?Ydh')
  break
  case '00000':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
  reply('Dih Najis Asw Mandang Fisik\nMuka Pas Pas An Ae Nyari Yang Good Locking,Ngaca Dek')
  break
//=============《 NSFW MENU 》==============//

case 'yuri':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
ini_result = await fetchJson(`https://ronove-bot-api.herokuapp.com/api/nsfw/${command}?apikey=Alphabot`)
get_result = ini_result.result
ini_img = await getBuffer(get_result)
mario4647.sendMessage(from, ini_img, image, {quoted:ftrol, caption: 'Jangan Sange Ama Kartun Tod🤣'})
break
case  'hentai': 
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
anu = await fetchJson(`https://waifu.pics/api/nsfw/neko`)
buffer = await getBuffer(anu.url)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'anal':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
aku = (`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=anal&apikey=hardianto`)
kon = await getBuffer(aku)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'lesbian':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
kau = (`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=lesbian&apikey=hardianto`)
kon = await getBuffer(kau)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'eroneko':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=eroNeko&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'bj':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=bJ&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'kitsune':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=kitsune&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'pussy':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = await getBuffer(`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=pussy&apikey=hardianto`)
mario4647.sendMessage(from, hai, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'wallpaper':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?sfw=wallpaper&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'neko2':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?sfw=neko&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'baka':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?sfw=baka&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'slap':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?sfw=slap&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'poke':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?sfw=poke&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'keta':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
hai = (`https://hardianto-chan.herokuapp.com/api/anime/random?nsfw=keta&apikey=hardianto`)
kon = await getBuffer(hai)
mario4647.sendMessage(from, kon, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'awoo':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
anu = await fetchJson(`https://waifu.pics/api/sfw/awoo`)
buffer = await getBuffer(anu.url)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'blowjob':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
anu = await fetchJson(`https://nekos.life/api/v2/img/blowjob`)
buffer = await getBuffer(anu.url)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'megumin':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
anu = await fetchJson(`https://waifu.pics/api/sfw/megumin`)
buffer = await getBuffer(anu.url)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'neko':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
anu = await fetchJson(`https://waifu.pics/api/nsfw/neko`)
buffer = await getBuffer(anu.url)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'trapnime':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
anu = await fetchJson(`https://waifu.pics/api/nsfw/trap`)
buffer = await getBuffer(anu.url)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol, thumbnail: fs.readFileSync('./arabotz/ara2.jpg')})
break
case 'ass':
case 'femdom':
case 'hentaigif':
case 'ahegao':
case 'cum':
case 'masturbation':
case 'jahy':
case 'orgy':
case 'thigs':
case 'panties':
case 'foot':
case 'gangbang':
case 'bdsm':
case 'ero':
case 'glasses':
if (!isGroup) return reply(mess.only.group)
if (!isNsfw) return reply(`Fitur Nsfw Belum Aktif Di Grup Ini\nKetik: ${prefix}nsfw\nUntuk Mengaktifkan`)
sticWait(from)
ini_result = await fetchJson(`https://ronove-bot-api.herokuapp.com/api/nsfw/${command}?apikey=Alphabot`)
get_result = ini_result.result
ini_img = await getBuffer(get_result)
mario4647.sendMessage(from, ini_img, image, {quoted:ftrol})
break
//=============《 FITUR STICKER 》==============//

case 'semoji':
if (args === 0) return reply('emojinya?')   
aku4 = args.join(' ')
emoji.get(`${aku4}`).then(emoji => {
link = `${emoji.images[10].url}`
sendWebp(from, `${link}`).catch(() => reply('gagal'))
})
break
case 'tourl':
if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedVideo ) && args.length == 0) {
boij = isQuotedImage || isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
owgi = await mario4647.downloadMediaMessage(boij)
res = await upload(owgi)
reply(res)
} else {
reply('kirim/reply gambar/video')
}
break
case 'nuliskiri':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
sticWait(from)
kon = (`https://hardianto-chan.herokuapp.com/api/nuliskiri?text=${command}&apikey=hardianto`)
anu = await getBuffer(kon)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Awas ketahuan 🗿'})
break
case 'nuliskanan':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
sticWait(from)
kon = (`https://hardianto-chan.herokuapp.com/api/nuliskanan?text=${command}&apikey=hardianto`)
anu = await getBuffer(kon)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Awas ketahuan 🗿'})
break
case 'foliokanan':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
sticWait(from)
kon = (`https://hardianto-chan.herokuapp.com/api/foliokanan?text=${command}&apikey=hardianto`)
anu = await getBuffer(kon)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Awas ketahuan 🗿'})
break
case 'foliokiri':
  if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
sticWait(from)
kon = (`https://hardianto-chan.herokuapp.com/api/foliokiri?text=${command}&apikey=hardianto`)
anu = await getBuffer(kon)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Awas ketahuan 🗿'})
break
case 'stickerlist':
case 'liststicker':
teks = '*Sticker List :*\n\n'
for (let awokwkwk of setik) {
teks += `- ${awokwkwk}\n`
}
teks += `\n*Total : ${setik.length}*\n\n_Untuk mengambil sticker silahkan reply pesan ini dengan caption nama sticker_`
mario4647.sendMessage(from, teks.trim(), extendedText, { quoted: ftrol, contextInfo: { "mentionedJid": setik } })
break
case 'addsticker':
if (!isOwner) return sticOwner(from)
if (!isQuotedSticker) return reply('Reply stiker')
nm = body.slice(12)
if (!nm) return reply('Nama sticker nya apa?')
boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
delb = await zero.downloadMediaMessage(boij)
setik.push(`${nm}`)
fs.writeFileSync(`./sticker/${nm}.webp`, delb)
fs.writeFileSync('./database/stick.json', JSON.stringify(setik))
mario4647.sendMessage(from, `Sukses, silahkan cek dengan *${prefix}liststicker*`, MessageType.text, { quoted: ftrol })
break
case 'delsticker':
if (!isOwner) return sticOwner(from)
try {
nmm = body.slice(12)
wanu = setik.indexOf(nmm)
setik.splice(wanu, 1)
fs.unlinkSync(`./sticker/${nmm}.webp`)
reply(`Sukses menghapus sticker ${body.slice(12)}`)
} catch (err){
console.log(err)
reply(mess.error.api)
}
break
case 'imagelist':
case 'listimage':
teks = '*Image List :*\n\n'
for (let awokwkwk of imagi) {
teks += `- ${awokwkwk}\n`
}
teks += `\n*Total : ${imagi.length}*\n\n_Untuk mengambil image silahkan reply pesan ini dengan caption nama image_`
mario4647.sendMessage(from, teks.trim(), extendedText, { quoted: ftrol, contextInfo: { "mentionedJid": imagi } })
break
case 'addimage':
if (!isOwner) return sticOwner(from)
if (!isQuotedImage) return reply('Reply image')
nm = body.slice(10)
if (!nm) return reply('Nama image nya apa?')
boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
delb = await zero.downloadMediaMessage(boij)
imagi.push(`${nm}`)
fs.writeFileSync(`./sticker/media/${nm}.jpg`, delb)
fs.writeFileSync('./database/image.json', JSON.stringify(imagi))
mario4647.sendMessage(from, `Sukses, silahkan cek dengan *${prefix}listimage*`, MessageType.text, { quoted: ftrol })
break
case 'delimage':
if (!isOwner) return sticOwner(from)
try {
nmm = body.slice(10)
wanu = imagi.indexOf(nmm)
imagi.splice(wanu, 1)
fs.unlinkSync(`./sticker/media/${nmm}.jpg`)
reply(`Sukses menghapus image ${body.slice(10)}`)
} catch (err){
console.log(err)
reply(mess.error.api)
}
break
case 'vnlist':
case 'listvn':
teks = '*VN List :*\n\n'
for (let awokwkwk of vien) {
teks += `- ${awokwkwk}\n`
}
teks += `\n*Total : ${vien.length}*\n\n_Untuk mengambil vn silahkan reply pesan ini dengan caption nama vn_`
mario4647.sendMessage(from, teks.trim(), extendedText, { quoted: ftrol, contextInfo: { "mentionedJid": vien } })
break
case 'darkjokes':
case 'meme':
buff = await getBuffer(`https://api.lolhuman.xyz/api/meme/darkjoke?apikey=${apikey1}`)
buttons = [{buttonId: `${prefix + command}`,buttonText:{displayText: `➡️Next`},type:1}]
imageMsg = (await mario4647.prepareMessageMedia(buff, "imageMessage", { thumbnail: buff, })).imageMessage
buttonsMessage = {footerText:'©Created By Mario 4647', imageMessage: imageMsg,
contentText:`DONE`,buttons,headerType:4}
prep = await mario4647.prepareMessageFromContent(from,{buttonsMessage},{quoted: ftrol})
mario4647.relayWAMessage(prep)
break
case 'rate':
rate = body.slice(1)
const ra =['4','9','17','28','34','48','59','62','74','83','97','100','29','94','75','82','41','39']
const te = ra[Math.floor(Math.random() * ra.length)]
mario4647.sendMessage(from, 'Pertanyaan : *'+rate+'*\n\nJawaban : '+ te+'%', text, { quoted: ftrol })
break
case 'apakah':
apakah = body.slice(1)
const apa =['Iya','Tidak','Bisa Jadi','Coba Ulangi','Tanyakan Ayam']
const kah = apa[Math.floor(Math.random() * apa.length)]
mario4647.sendMessage(from, 'Pertanyaan : *'+apakah+'*\n\nJawaban : '+ kah, text, { quoted: ftrol })
break
case 'kapankah':
kapankah = body.slice(1)
const kapan =['Besok','Lusa','Tadi','4 Hari Lagi','5 Hari Lagi','6 Hari Lagi','1 Minggu Lagi','2 Minggu Lagi','3 Minggu Lagi','1 Bulan Lagi','2 Bulan Lagi','3 Bulan Lagi','4 Bulan Lagi','5 Bulan Lagi','6 Bulan Lagi','1 Tahun Lagi','2 Tahun Lagi','3 Tahun Lagi','4 Tahun Lagi','5 Tahun Lagi','6 Tahun Lagi','1 Abad lagi','3 Hari Lagi','Tidak Akan Pernah']
const koh = kapan[Math.floor(Math.random() * kapan.length)]
mario4647.sendMessage(from, 'Pertanyaan : *'+kapankah+'*\n\nJawaban : '+ koh, text, { quoted: ftrol })
break
case 'bisakah':
bisakah = body.slice(1)
const bisa =['Bisa','Tidak Bisa','Coba Ulangi','Ngimpi kah?','yakin bisa?']
const keh = bisa[Math.floor(Math.random() * bisa.length)]
mario4647.sendMessage(from, 'Pertanyaan : *'+bisakah+'*\n\nJawaban : '+ keh, text, { quoted: ftrol })
break
case 'caripesan':
if (args.length < 1) return reply(`Penggunaan ${prefix}caripesan Hi|15`)
tekse = args.join('')
if (tekse.includes("|")) { 
try {
var ve = tekse.split("|")[0]
var za = tekse.split("|")[1]
if (za > 15) return reply('maksimal 15')
sampai = `${za}`
batas = parseInt(sampai) + 1
cok = await zero.searchMessages(`${ve}`, from, batas,1) 
if (cok.messages.lenght < 2) return reply('Pesan tidak ditemukan!') 
if (cok.messages.length < parseInt(batas)) reply(`Hanya ditemukan ${cok.messages.length - 1} Pesan`)
for (let i=1;i < cok.messages.length;i++) {
if (cok.messages[i].message) {
mario4647.sendMessage(from, `Nih pesannya!`, text, {quoted: cok.messages[i]}) 
}
}
} catch(e) {
console.log(e)
return reply(mess.error.api)
}
} else {
reply(`Penggunaan ${prefix}caripesan Hi|15`)
}
break
case 'tiktokaudio':
if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.error.api)
if (!q) return reply('Linknya?')
sticWait(from)
hx.ttdownloader(`${args[0]}`)
.then(result => {
var { wm, nowm, audio } = result
axios.get(`https://tinyurl.com/api-create.php?url=${nowm}`)
.then(async (a) => {
me = `*Link* : ${a.data}`
nowmm = await getBuffer(audio)
mario4647.sendMessage(from,nowmm ,MessageType.audio,{mimetype:'audio/mp4',quoted: ftrol})
})
})
break 
case 'patrick':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
sticWait(from)
fetch('https://raw.githubusercontent.com/rashidsiregar28/data/main/patrik')
.then(res => res.text())
.then(body => {
let tod = body.split("\n");
let pjr = tod[Math.floor(Math.random() * tod.length)];
sendWebp(from, pjr)
}
)
break
case 'attp':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Example: ${prefix + command} Hai`)
buffer = await getBuffer(`https://api.xteam.xyz/attp?file&text=${encodeURI(q)}`)
mario4647.sendMessage(from, buffer, sticker, { quoted: ftrol })
break
case 'sticker':
case 'stiker':
case 's':
if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
let media = await mario4647.downloadAndSaveMediaMessage(encmedia, './database/media_user')
ran = getRandom('.webp')
await ffmpeg(`./${media}`)
.input(media)
.on('start', function (cmd) {
console.log(`Started : ${cmd}`)
})
.on('error', function (err) {
console.log(`Error : ${err}`)
fs.unlinkSync(media)
reply(mess.error.stick)
})
.on('end', function () {
console.log('Finish')
buffer = fs.readFileSync(ran)
costum(buffer, sticker, Verived, `𝐉𝐚𝐧??𝐚𝐧 𝐋𝐮𝐩𝐚 Donasi`)
fs.unlinkSync(media)
fs.unlinkSync(ran)
})
.addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
.toFormat('webp')
.save(ran)
} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
let media = await mario4647.downloadAndSaveMediaMessage(encmedia, './database/media_user')
ran = getRandom('.webp')
sticWait(from)
await ffmpeg(`./${media}`)
.inputFormat(media.split('.')[1])
.on('start', function (cmd) {
console.log(`Started : ${cmd}`)
})
.on('error', function (err) {
console.log(`Error : ${err}`)
fs.unlinkSync(media)
tipe = media.endsWith('.mp4') ? 'video' : 'gif'
reply(`Gagal, Pada Saat Mengkonversi ${tipe} Ke Stiker. Pastikan Untuk Video Yang Dikirim Tidak Lebih Dari 9 Detik`)
})
.on('end', function () {
console.log('Finish')
costum(fs.readFileSync(ran), sticker, Verived, `~ Nih Dah Jadi Gif Stikernya`)
fs.unlinkSync(media)
fs.unlinkSync(ran)
})
.addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
.toFormat('webp')
.save(ran)
} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
let media = await mario4647.downloadAndSaveMediaMessage(encmedia, './database/media_user')
ranw = getRandom('.webp')
ranp = getRandom('.png')
sticWait(from)
keyrmbg = 'bcAvZyjYAjKkp1cmK8ZgQvWH'
await removeBackgroundFromImageFile({ path: media, apiKey: keyrmbg, size: 'auto', type: 'auto', ranp }).then(res => {
fs.unlinkSync(media)
let buffer = Buffer.from(res.base64img, 'base64')
fs.writeFileSync(ranp, buffer, (err) => {
if (err) return reply('Gagal, Terjadi Kesalahan, Silahkan Coba Beberapa Saat Lagi.')
})
exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
fs.unlinkSync(ranp)
if (err) return reply(mess.error.stick)
mario4647.sendMessage(from, fs.readFileSync(ranw), sticker, { quoted: ftrol })
fs.unlinkSync(ranw)
})
})
} else {
reply(`Kirim Gambar Dengan Caption ${prefix}sticker Atau Tag Gambar Yang Sudah Dikirim`)
}
break
case 'dadu':
random = Math.floor(Math.random() * 6) + 1
damdu = fs.readFileSync(`./sticker/${random}.webp`)
mario4647.sendMessage(from, damdu, sticker, {quoted: ftrol})
break
case 'toimg':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isQuotedSticker) return reply(' reply stickernya gan')
encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
media = await mario4647.downloadAndSaveMediaMessage(encmedia, './database/media_user')
ran = getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return reply(' Gagal, pada saat mengkonversi sticker ke gambar ')
buffer = fs.readFileSync(ran)
costum(buffer, image, Verived, ` © Mario 4647`)
fs.unlinkSync(ran)
})
break
case 'tomp3':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
mario4647.updatePresence(from, Presence.recording)
if (!isQuotedVideo) return reply('Reply Video nya Tod')
sticWait(from)
encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
media = await mario4647.downloadAndSaveMediaMessage(encmedia, './database/media_user')
ran = getRandom('.mp4')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return reply('Gagal, pada saat mengkonversi video ke mp3')
bufferlkj = fs.readFileSync(ran)
mario4647.sendMessage(from, bufferlkj, audio, { mimetype: 'audio/mp4', quoted: ftrol })
fs.unlinkSync(ran)
})
break
case 'tovideo':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isQuotedSticker) return reply('Reply stikernya')
sticWait(from)
anumedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
anum = await mario4647.downloadAndSaveMediaMessage(anumedia, './database/media_user')
ran = getRandom('.webp')
exec(`ffmpeg -i ${anum} ${ran}`, (err) => {
fs.unlinkSync(anum)
buffer = fs.readFileSync(ran)
mario4647.sendMessage(from, buffer, video, { quoted: ftrol, caption: 'Done...  © Mario 4647' })
fs.unlinkSync(ran)
})
break
case 'suit':
if (args.length < 1) return reply('Pilih gunting/batu/kertas')
if (args[0] === 'gunting' ) {
gunting = [
"Kamu *Gunting*\nAku *Kertas*\nKamu Menang 😔",
"Kamu *Gunting*\nAku *Batu*\nKamu Kalah 🙂",
"Kamu *Gunting*\nAku *Gunting*\nKita Seri 😏"
]
gun = gunting[Math.floor(Math.random() * gunting.length)]
reply(gun)
} else if (args[0] === 'kertas') {
ker = [
"Kamu *Kertas*\nAku *Batu*\nKamu Menang 😔",
"Kamu *Kertas*\nAku *Gunting*\nKamu Kalah 🙂",
"Kamu *Kertas*\nAku *Kertas*\nKita Seri 😏"
]
kertas = ker[Math.floor(Math.random() * ker.length)]
reply(kertas)
} else if (args[0] === 'batu') {
bat = [
"Kamu *Batu*\nAku *Gunting*\nKamu Menang ??",
"Kamu *Batu*\nAku *Kertas*\nKamu Kalah 🙂",
"Kamu *Batu*\nAku *Batu*\nKita Seri 😏"
]
batu = bat[Math.floor(Math.random() * bat.length)]
reply(batu)
} else {
reply('Pilih gunting/batu/kertas')
}
break

//=============《 FITUR OWNER 》==============//
case 'mute':
               if (!isOwner) return sticOwner(from)
               if (!isGroup) return reply(mess.only.group)
               if (!isGroupAdmins) return sticAdmin(from)
               if (args.length < 1) return reply('!mute enable/disable')
               if (args[0].toLowerCase() === 'enable'){
               if (isMuted) return reply(`udah di mute`)
               mute.push(from)
               fs.writeFileSync('./database/mute.json', JSON.stringify(mute))
               reply(`*...:* *MUTE ON* *:...*\n\nPerhatian untuk member grup\nBot telah di mute di grup ${groupName} , Silahkan menggunakan bot dengan sewajarnya\n\n_*${botname}*_`)
               } else if (args[0].toLowerCase() === 'disable'){
               anu = mute.indexOf(from)
               mute.splice(anu, 1)
               fs.writeFileSync('./database/mute.json', JSON.stringify(mute))
               reply(`*...:* *𝙈𝙐𝙏𝙀 𝙊𝙁𝙁* *:...*\n\nPerhatian untuk member grup\nBot telah di unmute di grup ${groupName} , Silahkan menggunakan bot dengan sewajarnya\n\n_*${botname}*_`)
               } else {
               reply(`Pilih enable atau disable`)
}
               break
case 'virtex':
	if (!isOwner) return sticOwner(from)
katalog(`${virtex(prefix)}`)
katalog(`${virtex2(prefix)}`)
break
case 'addvn':
if (!isOwner) return sticOwner(from)
if (!isQuotedAudio) return reply('Reply audio')
nm = body.slice(7)
if (!nm) return reply('Nama vn nya apa?')
boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
delb = await zero.downloadMediaMessage(boij)
vien.push(`${nm}`)
fs.writeFileSync(`./sticker/media/${nm}.mp3`, delb)
fs.writeFileSync('./database/vn.json', JSON.stringify(vien))
mario4647.sendMessage(from, `Sukses, silahkan cek dengan *${prefix}listvn*`, MessageType.text, { quoted: ftrol })
break
case 'delvn':
if (!isOwner) return sticOwner(from)
try {
nmm = body.slice(7)
wanu = vien.indexOf(nmm)
vien.splice(wanu, 1)
fs.unlinkSync(`./sticker/media/${nmm}.mp3`)
reply(`Sukses menghapus vn ${body.slice(7)}`)
} catch (err){
console.log(err)
reply(mess.error.api)
}
break
case 'mode':
if (!isOwner) return sticOwner(from)
but = [
{ buttonId: '!public', buttonText: { displayText: 'PUBLIC📛' }, type: 1 },
{ buttonId: '!self', buttonText: { displayText: 'SELF📛' }, type: 1 }
]
sendButton(from, "Silahkan Pilih Mode Bot Self/Public", faketeks, but, mek)
break
case 'public':
				if (!isOwner) return sticOwner(from)
			publik = true
				reply('*「 PUBLIC-MODE 」*')
			break
			case 'self':
			if (!isOwner) return sticOwner(from)
				publik = false
				reply('*「 SELF-MODE 」*')
			break
case 'premium': 
              if (!isOwner) return sticOwner(from)
              if (args[0] === 'add') {
              if (mek.message.extendedTextMessage != undefined) {
              mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid

              premium.addPremiumUser(mentioned[0], args[2], _premium)
              reply(`*「 PREMIUM ADDED 」*\n\n➸ *ID*: ${mentioned[0]}\n➸ *Expired*: ${ms(toMs(args[2])).days} day(s) ${ms(toMs(args[2])).hours} hour(s) ${ms(toMs(args[2])).minutes} minute(s)`)
                        
              } else {
                            
              premium.addPremiumUser(args[1] + '@s.whatsapp.net', args[2], _premium)
              reply(`*「 PREMIUM ADDED 」*\n\n➸ *ID*: ${args[1]}@s.whatsapp.net\n➸ *Expired*: ${ms(toMs(args[2])).days} day(s) ${ms(toMs(args[2])).hours} hour(s) ${ms(toMs(args[2])).minutes} minute(s)`)
}
              } else if (args[0] === 'del') {
              if (mek.message.extendedTextMessage != undefined) {
              mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
            _premium.splice(premium.getPremiumPosition(mentioned[0], _premium), 1)
              fs.writeFileSync('./database/premium.json', JSON.stringify(_premium))
              reply(mess.success)
              } else {
            _premium.splice(premium.getPremiumPosition(args[1] + '@s.whatsapp.net', _premium), 1)
              fs.writeFileSync('./database/premium.json', JSON.stringify(_premium))
              reply(mess.success)
}
              } else {
              reply(mess.wrongFormat)
}
              break
       case 'premiumcheck':
       case 'cekpremium': 
              if (!isPremium) return reply(mess.only.premium)
              const cekExp = ms(await premium.getPremiumExpired(sender, _premium) - Date.now())
              reply(`*「 PREMIUM EXPIRE 」*\n\n➸ *ID*: ${sender}\n➸ *Premium left*: ${cekExp.days} day(s) ${cekExp.hours} hour(s) ${cekExp.minutes} minute(s)`)
              break
       case 'listprem':
       case 'listpremium':          
              let txt = `「 *PREMIUM USER LIST* 」\n\n`
              let men = [];
              for (let i of _premium){
              men.push(i.id)
              const checkExp = ms(i.expired - Date.now())
              txt += `➸ *ID :* @${i.id.split("@")[0]}\n➸ *Expired*: ${checkExp.days} day(s) ${checkExp.hours} hour(s) ${checkExp.minutes} minute(s)\n\n`
}
              mentions(txt, men, true)
              break
case 'join':
				if (!isOwner && !mek.key.fromMe) return sticOwner(from)
				 if (args.length < 1) return ephe('Link nya mana?')
					mario4647.query({
json:["action", "invite", `${args[0].replace('https://chat.whatsapp.com/','')}`]
})
reply('Sukses bergabung dalam group')
break
case 'ban':
if (!isOwner) return sticOwner(from)
bnnd = body.slice(5)
ban.push(`${args[0].replace('@','')}@s.whatsapp.net`)
fs.writeFileSync('./database/banned.json', JSON.stringify(ban))
reply(`Berhasil membanned nomor : wa.me/${bnnd} `)
break
case 'unban': 
if (!isOwner) return sticOwner(from)
delp = body.slice(7)
ban.splice(`${delp}@s.whatsapp.net`, 1)
fs.writeFileSync('./database/banned.json', JSON.stringify(ban))
reply(`Berhasil Menghapus wa.me/${delp} dari banned`)
break
case 'listban':
		case 'banlist':
					teks = '*List Ban:*\n\n'
					for (let manikgans of ban) {
						teks += `- ${manikgans}\n`
					}
					teks += `\n*Total : ${ban.length}*`
					mario4647.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": ban } })
					break
case 'sharelock':
 if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Kota|Nama`)
 if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
kntl = `${args.join(' ')}`
nama = kntl.split("|")[0];
impostor = kntl.split("|")[1];
mario4647.sendMessage(from, {
name: nama,
address: impostor,
jpegThumbnail: zero}, MessageType.liveLocation, {quoted: ftrol})
break
case 'rulesbot':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
ruls =`*── 「 RULES 」 ──*

1. Jangan Spam Bot. 
Sanksi : *DENDA 5K*

2. Jangan Telepon Bot.
Sanksi : *SOFT BLOCK*

3. Jangan VC Bot.
Sanksi : *SOFT BLOCK*

4. Jangan Mengeksploitasi Bot.
Sanksi : *PERMANENT BLOCK*

5. Jangan Kick Bot Dari Grup Kalian.
Sanksi : *BOT TIDAK BISA MASUK LAGI*

Jika Sudah Dipahami Rulesnya, Silakan Ketik *${prefix}menu* Untuk Memulai!`
but = [{ buttonId: `${prefix}owner`, buttonText: { displayText: '🌸OWNER🌸' }, type: 1 }]
sendButton(from, ruls, faketeks, but, mek)
break
case 'rulesgc':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (!isGroup) return reply(mess.only.group)
if (!isAntiLink) return reply('ANTILINK GRUB HARUS AKTIF')
ruls =`*Syarat & Ketentuan ${groupMetadata.subject}*
Harus Di Patuhi, Kalau Tidak Di Kick

1. Dilarang Toxic. 
2. Dilarang Share Link.
3. Dilarang Spam.
4. Dilarang Share 18+ Di Grup.

Kalo Sudah Dipahami Rules Nya
*Silahkan Di Patuhi Rules Nya*`
but = [{ buttonId: `${prefix}owner`, buttonText: { displayText: `${groupMetadata.subject}` }, type: 1 }]
sendButton(from, ruls, faketeks, but, mek)
break
case 'owner' :
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
but = [
{ buttonId: '!owner1', buttonText: { displayText: `${ownername}` }, type: 1 },
{ buttonId: '!owner2', buttonText: { displayText: `${ownername2}` }, type: 1 }
]
sendButton(from, `${tampilUcapan}\nHay Kak ${pushname} Silahkan Pilih Tombol Di Bawah Yak Untuk Info Owner ${botname}🍃`, faketeks, but, mek)
break
case 'owner1':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
members_ids = []
for (let mem of groupMembers) {
members_ids.push(mem.jid)
}
vcard2 = 'BEGIN:VCARD\n'
+ 'VERSION:3.0\n'
+ `FN:${ownername}\n`
+ `ORG: Creator ${ownername} ;\n`
+ `TEL;type=CELL;type=VOICE;waid=${owner}:${owner}\n`
+ 'END:VCARD'.trim()
mario4647.sendMessage(from, {displayName: `Creator ${ownername}`, vcard: vcard2}, contact, 
{ quoted: ftrol, 
})
reply('Tuh Kontak Owner Ku Kak><\nDia Owner Laki Laki Ku Yang Baik,Dia Selalu Mengutamakan Update Dan Kepuasan Para Buyer Nya🍃')
break
case 'owner2':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
members_ids = []
for (let mem of groupMembers) {
members_ids.push(mem.jid)
}
vcard2 = 'BEGIN:VCARD\n'
+ 'VERSION:3.0\n'
+ `FN:${ownername2}\n`
+ `ORG: Creator ${ownername2} ;\n`
+ `TEL;type=CELL;type=VOICE;waid=${owner2}:${owner2}\n`
+ 'END:VCARD'.trim()
mario4647.sendMessage(from, {displayName: `Creator ${ownername2}`, vcard: vcard2}, contact, 
{ quoted: ftrol, 
})
reply('Tuh Kontak Owner Ku Yang Paling Cantik><\nDia Owner Cewe Ku,Dia Baik Banget')
break
case 'bc':
					mario4647.updatePresence(from, Presence.composing)
					if (!isOwner && !mek.key.fromMe) return sticOwner(from)
					if (args.length < 1) return reply('Teksnya?')
					anu = await mario4647.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
						buff = await mario4647.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							mario4647.sendMessage(_.jid, buff, image, { viewOnce:true, caption: `${body.slice(4)}`})
						}
						reply(`Sukses mengirim Broadcast ${body.slice(4)}`)
						} else if (isMedia && !mek.message.videoMessage || isQuotedVideo) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
						buff = await mario4647.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							mario4647.sendMessage(_.jid, buff, video, { viewOnce:true, caption: `${body.slice(4)}`})
						}
						reply(`Sukses mengirim Broadcast ${body.slice(4)}`)
						} else if (isMedia && !mek.message.videoMessage || isQuotedVideo) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
						buff = await mario4647.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							mario4647.sendMessage(_.jid, buff, video, { mimetype: Mimetype.gif, quoted: finv, contextInfo: { forwardingScore: 508, isForwarded: true}, caption: `${body.slice(4)}` })
						}
						reply(`Sukses mengirim Broadcast ${body.slice(4)}`)
					} else {
						for (let _ of anu) {
							//sendMess(_.jid, `${body.slice(4)}`)
buttons = [{buttonId: `${prefix}menu`, buttonText: {displayText: 'MENU📑'}, type: 1},{buttonId: `${prefix}owner`, buttonText: {displayText: 'OWNER👤'}, type: 1}]
const btnbc = {
    contentText: `${body.slice(4)}`,
    footerText: '*_BROADCAST_*',
    buttons: buttons,
    headerType: 1
}
await mario4647.sendMessage(_.jid, btnbc, MessageType.buttonsMessage, {quoted: ftrol})
						}
						reply(`Sukses mengirim Broadcast:\n${body.slice(4)}`)
					}
					break
case 'report':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
const pesan = body.slice(8)
if (pesan.length > 300) return pras.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', text, { quoted: ftrol })
var nomor = mek.participant
const teks1 = `*[REPORT]*\nNomor : @${nomor.split("@s.whatsapp.net")[0]}\nPesan : ${pesan}`
var options = {
text: teks1,
contextInfo: { mentionedJid: [nomor] },
}
mario4647.sendMessage(`6282110232966@s.whatsapp.net`, options, text, { quoted: ftrol })
reply('Masalah Telah Di Laporkan Ke Owner BOT, Mohon Tunggu Untuk Proses Perbaikan')
break
case 'bugreport': 
              if (args.length < 1) return reply(`Ketik ${prefix}bugreport [fiturnya] [Error Nya Gimana]`) 
              teks = args.join(' ')
              reply('Terima Kasih Telah Melaporkan Bug Pada Owner, Jika Itu Sekedar Iseng Maka Akan Di Ban Oleh Bot!')
              mario4647.sendMessage('6282110232966@s.whatsapp.net',`*Bug Report:* ${teks}`, text)
              break
       case 'jawaban':
              if (args.length < 1) return reply(`Ketik ${prefix}jawaban [jawaban]`) 
              teks = args.join(' ')
              reply('Terima Kasih Telah Menjawab')
              mario4647.sendMessage('6282110232966@s.whatsapp.net',`*Bug Report:* ${teks}`, text)
              break
case 'spam':
if (!isOwner && !mek.key.fromMe) return reply(mess.only.owner)
if (!q) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix}spam teks|jumlah`)
argzi = q.split("|")
if (!argzi) return reply(`Penggunaan ${prefix}spam teks|jumlah`)
if (Number(argzi[1]) >= 50) return reply('Kebanyakan!')
if (isNaN(argzi[1])) return reply(`Harus berupa angka`)
for (let i = 0; i < argzi[1]; i++){
mario4647.sendMessage(from, argzi[0], MessageType.text)
}
break
case 'setppwa':
if (!isOwner && !mek.key.fromMe) return reply(mess.only.owner)
if (!isQuotedImage) return reply(`Reply Imagenya!`)
enmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
media = await mario4647.downloadAndSaveMediaMessage(enmedia)
await mario4647.updateProfilePicture(botNumber, media)
reply('*Makasih Profile Barunya :)*')
break
case 'setbio':{
if (!isOwner && !mek.key.fromMe) return reply(mess.only.owner)
mario4647.setStatus(q)
.then((res) => reply(jsonformat(res)))
.catch((err) => reply(jsonformat(err)))
reply(mess.success)
}
break
case 'leave':
if (!isOwner && !mek.key.fromMe) return reply(mess.only.owner)
if (!isOwner) return sticOwner(from)
if (!isGroup) return reply(mess.only.group)
setTimeout( () => {
mario4647.groupLeave(from) 
}, 2000)
setTimeout( () => {
reply('Selamat Tinggal...')
}, 0)
break
//-----------------[FITUR MAKER]-------------------//
case 'harrypotter':
if (args.length == 0) return reply(`Teks Nya Mana ?\nContoh: ${prefix + command} Mario 4647`)
zerr = args.join(" ")
buffer = await getBuffer(`https://api.lolhuman.xyz/api/photooxy1/${command}?apikey=${zero}&text=${zerr}`)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: '*©Creator : Mario 4647*'})
break
case 'phkomen':
if (args.length == 0) return reply(`Teksnya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
username = args[0]
comment = args[2]
buffer = await getBuffer(`https://api.lolhuman.xyz/api/phcomment?apikey=${zerokey}&img=https://i.ibb.co/JdfQ73m/photo-2021-02-05-10-13-39.jpg&text=${comment}&username=${username}`)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: '*©Creator : Mario 4647*'})
break
case 'blackpink':
if (args.length == 0) return reply(`Teksnya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
zerr = args.join(" ")
buffer = await getBuffer(`https://api.lolhuman.xyz/api/textprome/${command}?apikey=${zerokey}&text=${zerr}`)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol})
break
case 'pornhub':
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
txt1 = args[0]
txt2 = args[1]
buffer = await getBuffer(`https://api.lolhuman.xyz/api/textprome2/${command}?apikey=${zerokey}&text1=${txt1}&text2=${txt2}`)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol })
break
case 'text1917':
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
zerr = args.join(" ")
buffer = await getBuffer(`https://api.lolhuman.xyz/api/textprome/text1917?apikey=${zerokey}&text=${zerr}`)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol})
break
case 'freefire':
if (args.length == 0) return reply(`Teksnya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
zerr = args.join(" ")
buffer = await getBuffer(`https://api.lolhuman.xyz/api/ephoto1/freefire?apikey=${zerokey}&text=${zerr}`)
mario4647.sendMessage(from, buffer, image, { quoted: ftrol})
break
case 'pubg':
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
txt1 = args[0]
txt2 = args[1]
buffer = await getBuffer(`https://api.lolhuman.xyz/api/photooxy2/pubg?apikey=${zerokey}&text1=${txt1}&text2=${txt2}`)
mario4647.sendMessage(from, buffer, image, { quoted: mek })
break
case 'ytkomen':
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
username = args[0]
comment = args[2]
buffer = await getBuffer(`https://api.lolhuman.xyz/api/ytcomment?apikey=${zerokey}&username=${username}&comment=${comment}&img=https://i.ibb.co/JdfQ73m/photo-2021-02-05-10-13-39.jpg`)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: '*©Creator : Mario 4647*'})
break
case 'nulis':
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
zerr = args.join(" ")
buffer = await getBuffer(`https://api.lolhuman.xyz/api/nulis?apikey=${zerokey}&text=${zerr}`)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Awas ketahuan 🗿'})
break
case 'fakedonald':
if (args.length == 0) return reply(`Teks Nya Mana Tod ?\nContoh : ${prefix + command} Mario 4647`)
zerr = args.join(" ")
buffer = await getBuffer(`https://api.lolhuman.xyz/api/tweettrump?apikey=${zerokey}&text=${zerr}`)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: '*©Creator : Mario 4647*'})
break

//=============《 FITUR ISLAMI 》==============//

case 'listsurah':
get_result = await fetchJson(`https://api.lolhuman.xyz/api/quran?apikey=${zerokey}`)
get_result = get_result.result
zerr = '*List Surah :*\n'
for (var x in get_result) {
zerr += `${x}. ${get_result[x]}\n`
}
reply(zerr)
break
case 'asmaulhusna':
get_result = await fetchJson(`https://api.lolhuman.xyz/api/asmaulhusna?apikey=${zerokey}`)
get_result = get_result.result
zerr = `*Urutan :* ${get_result.index}\n`
zerr += `*Latin :* ${get_result.latin}\n`
zerr += `*Arab :* ${get_result.ar}\n`
zerr += `*Indonesia :* ${get_result.id}\n`
zerr += `*English :* ${get_result.en}`
reply(zerr)
break
case 'jadwalsholat':
if (args.length == 0) return reply(`Nama Kotanya Mana ?\nContoh : ${prefix + command} Temanggung`)
daerah = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${daerah}?apikey=${zerokey}`)
get_result = get_result.result
zerr = `*Wilayah :* ${get_result.wilayah}\n`
zerr += `*Tanggal :* ${get_result.tanggal}\n`
zerr += `*Sahur :* ${get_result.sahur}\n`
zerr += `*Imsak :* ${get_result.imsak}\n`
zerr += `*Subuh :* ${get_result.subuh}\n`
zerr += `*Terbit :* ${get_result.terbit}\n`
zerr += `*Dhuha :* ${get_result.dhuha}\n`
zerr += `*Dzuhur :* ${get_result.dzuhur}\n`
zerr += `*Ashar :* ${get_result.ashar}\n`
zerr += `*Maghrib :* ${get_result.maghrib}\n`
zerr += `*Isya :* ${get_result.isya}`
reply(zerr)
break
case 'kisahnabi':
if (args.length == 0) return reply(`Example : ${prefix + command} Muhammad`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/kisahnabi/${query}?apikey=${zerokey}`)
get_result = get_result.result
zerr = `*Nama :* ${get_result.name}\n`
zerr += `*Lahir :* ${get_result.thn_kelahiran}\n`
zerr += `*Umur :* ${get_result.age}\n`
zerr += `*Tempat :* ${get_result.place}\n`
zerr += `*Story :* ${get_result.story}`
reply(zerr)
break
case 'alquran':
if (args.length < 1) return reply(`Nomer Surah Nya Mana ?\nContoh : ${prefix + command} 18\nAtau ${prefix + command} 18/10\nAtau ${prefix + command} 18/1-10`)
urls = `https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${zerokey}`
quran = await fetchJson(urls)
result = quran.result
ayat = result.ayat
zerr = `QS. ${result.surah} : 1-${ayat.length}\n\n`
for (var x of ayat) {
arab = x.arab
nomor = x.ayat
latin = x.latin
indo = x.indonesia
zerr += `${arab}\n${nomor}. ${latin}\n${indo}\n\n`
}
zerr = zerr.replace(/<u>/g, "").replace(/<\/u>/g, "")
zerr = zerr.replace(/<strong>/g, "").replace(/<\/strong>/g, "")
zerr = zerr.replace(/<u>/g, "").replace(/<\/u>/g, "")
reply(zerr)
break
case 'alquranaudio':
if (args.length == 0) return reply(`Nomer Surah Nya Mana ?\nContoh : ${prefix + command} 18\nAtau ${prefix + command} 18/10`)
surah = args[0]
buffer = await getBuffer(`https://api.lolhuman.xyz/api/quran/audio/${surah}?apikey=${zerokey}`)
await mario4647.sendMessage(from, buffer, audio, { quoted: fmen, mimetype: Mimetype.mp4Audio })
break

//=============《 FITUR DOWNLOAD 》==============//

case 'tiktokmusic':
if (args.length == 0) return reply(`Link Nya Mana Tod\nContoh: ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
link = args[0]
get_audio = await getBuffer(`https://api.lolhuman.xyz/api/tiktokmusic?apikey=${zerokey}&url=${link}`)
mario4647.sendMessage(from, get_audio, audio, { mimetype: Mimetype.mp4Audio, quoted: ftrol})
break
case 'igdl':
if (args.length == 0) return reply(`Link Nya Mana Tod ?\nContoh : ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
url = args[0]
url = await fetchJson(`https://api.lolhuman.xyz/api/instagram?apikey=${zerokey}&url=${url}`)
url = url.result
type = image
if (url.includes(".mp4")) type = video
buffer = await getBuffer(url)
mario4647.sendMessage(from, buffer, type, { quoted: ftrol})
break
case 'fbdl':
if (args.length == 0) return reply(`Link Nya Mana Tod ?\nContoh : ${prefix + command} https://id-id.facebook.com/SamsungGulf/videos/video-bokeh/561108457758458/`)
url = args[0]
url = await fetchJson(`https://api.lolhuman.xyz/api/facebook?apikey=${zerokey}&url=${url}`)
url = url.result[0].link
buffer = await getBuffer(url)
mario4647.sendMessage(from, buffer, video, { quoted: ftrol})
break
case 'brainly':
if (args.length == 0) return reply(`Apa Yang Mau Di Cari Tod ?\nContoh : ${prefix + command} Soekarno adalah`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/brainly?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
zerr = "Result Search : \n"
for (var x of get_result) {
zerr += `${x.title}\n`
zerr += `${x.url}\n\n`
}
reply(zerr)
break
case 'lirik':
if (args.length == 0) return reply(`Judul Lagu Nya Mana Tod ?\nContoh : ${prefix + command} Melukis Senja`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/lirik?apikey=${zerokey}&query=${query}`)
reply(get_result.result)
break
case 'tiktoknowm':
if (args.length == 0) return reply(`Link Nya Mana Tod ?\nContoh : ${prefix + command} https://vt.tiktok.com/ZSwWCk5o/`)
url = args[0]
url = `https://api.lolhuman.xyz/api/tiktok?apikey=${zerokey}&url=${url}`
get_result = await fetchJson(url)
buffer = await getBuffer(get_result.result.link)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol})
break
case 'pinterest':
if (args.length == 0) return reply(`Example: ${prefix + command} Xrutz`)
query = args.join(" ")
url = await fetchJson(`https://api.lolhuman.xyz/api/pinterest?apikey=${zerokey}&query=${query}`)
url = url.result
buffer = await getBuffer(url)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol})
break
case 'spotifysearch':
if (args.length == 0) return reply(`Judul Lagu Nya Mana Tod ?\nContoh : ${prefix + command} Melukis Senja`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/spotifysearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
zerr = ""
for (var x of get_result) {
zerr += `*Title :* ${x.title}\n`
zerr += `*Artists :* ${x.artists}\n`
zerr += `*Duration :* ${x.duration}\n`
zerr += `*Link :* ${x.link}\n`
zerr += `*Preview :* ${x.preview_url}\n\n\n`
}
reply(zerr)
break
case 'play':
             if (args.length < 1) return reply(`Kirim perintah *${prefix}play query*`)
             sticWait(from)
             let yut = await yts(q)
             yta(yut.videos[0].url)             
             .then(async(res) => {
             const { thumb, title, filesizeF, filesize } = res
             const capti = `𝗬𝗢𝗨𝗧𝗨𝗕𝗘 𝗣𝗟𝗔𝗬🍁
		     
•💬 Judul : ${yut.all[0].title}
•🎥 ID Video : ${yut.all[0].videoId}
•⏰️ Diupload Pada : ${yut.all[0].ago}
•👁️️ Views : ${yut.all[0].views}
•▶️ Durasi : ${yut.all[0].timestamp}
•📍 Channel : ${yut.all[0].author.name}
•🔗 Link Channel : ${yut.all[0].author.url}`
             ya = await getBuffer(thumb)
             py =await mario4647.prepareMessage(from, ya, image)
             gbutsan = [{buttonId: `${prefix}ytmp3 ${yut.all[0].url}`, buttonText: {displayText: 'AUDIO'}, type: 1},{buttonId: `${prefix}ytmp4 ${yut.all[0].url}`, buttonText: {displayText: 'VIDEO'}, type: 1}]
             gbuttonan = {
             imageMessage: py.message.imageMessage,
             contentText: capti,
             footerText: 'Silahkan Pilih Jenis File Dibawah Ini☕',
             buttons: gbutsan,
             headerType: 4
}
             await mario4647.sendMessage(from, gbuttonan, MessageType.buttonsMessage)})
             break 
case 'playmp3':
if (args.length == 0) return await reply(`Judul Lagunya Mana Tod\nContoh : ${prefix + command} melukis senja`)
sticWait(from)
await fetchJson(`https://api.lolhuman.xyz/api/ytsearch?apikey=${zerokey}&query=${args.join(" ")}`)
.then(async(result) => {
await fetchJson(`https://api.lolhuman.xyz/api/ytaudio2?apikey=${zerokey}&url=https://www.youtube.com/watch?v=${result.result[0].videoId}`)
.then(async(result) => {
result = result.result
caption = `❖ Title    : *${result.title}*\n`
caption += `❖ Size     : *${result.size}*`
ini_buffer = await getBuffer(result.thumbnail)
await mario4647.sendMessage(from, ini_buffer, image, { quoted: ftrol, caption: caption })
get_audio = await getBuffer(result.link)
await mario4647.sendMessage(from, get_audio, audio, { mimetype: 'audio/mp4', filename: `${result.title}.mp3`, quoted: ftrol})
})
})
break
case "playmp4":
if (args.length === 0)
return reply(`Kirim perintah *${prefix}video* _Judul lagu yang akan dicari_`)
sticWait(from)
var srch = args.join("")
aramas = await yts(srch)
aramat = aramas.all;
var mulaikah = aramat[0].url;
try {
ytv(mulaikah).then((res) => {
const { dl_link, thumb, title, filesizeF, filesize } = res;
axios
.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
.then(async (a) => {
if (Number(filesize) >= 100000)
return sendMediaURL(from,thumb,`*PLAY VIDEO*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
const captions = `*PLAY VIDEO*\n\n*Title* : ${title}\n*Ext* : MP4\n*Size* : ${filesizeF}\n*Link* : ${a.data}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
sendMediaURL(from, thumb, captions)
await sendMediaURL(from, dl_link).catch(() => reply("error"))
})
})
} catch (err) {
reply(mess.error.api)
}
break
case 'ytsearch':
if (args.length == 0) return reply(`Judul Video Yg Mau Di Cari Tod\nContoh : ${prefix + command} Melukis Senja`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/ytsearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = ""
for (var x of get_result) {
ini_txt += `Title : ${x.title}\n`
ini_txt += `Views : ${x.views}\n`
ini_txt += `Published : ${x.published}\n`
ini_txt += `Thumbnail : ${x.thumbnail}\n`
ini_txt += `Link : https://www.youtube.com/watch?v=${x.videoId}\n\n`
}
reply(ini_txt)
break
case 'ytmp4':
if (args.length == 0) return reply(`Link Nya Mana Tod\nContoh: ${prefix + command} https://www.youtube.com/watch?v=qZIQAk-BUEc`)
ini_link = args[0]
get_result = await fetchJson(`https://api.lolhuman.xyz/api/ytvideo2?apikey=${zerokey}&url=${ini_link}`)
get_result = get_result.result
ini_txt = `${get_result.title} - ${get_result.size}`
ini_buffer = await getBuffer(get_result.thumbnail)
await mario4647.sendMessage(from, ini_buffer, image, { quoted: ftrol, caption: ini_txt })
get_audio = await getBuffer(get_result.link)
await mario4647.sendMessage(from, get_audio, video, { mimetype: 'video/mp4', filename: `${get_result.title}.mp4`, quoted: ftrol, caption: '©Creator : Mario 4647'})
break
//=============《 FITUR ANIME 》==============//

case 'character':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/character?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = `Id : ${get_result.id}\n`
ini_txt += `Name : ${get_result.name.full}\n`
ini_txt += `Native : ${get_result.name.native}\n`
ini_txt += `Favorites : ${get_result.favourites}\n`
ini_txt += `Media : \n`
ini_media = get_result.media.nodes
for (var x of ini_media) {
ini_txt += `- ${x.title.romaji} (${x.title.native})\n`
}
ini_txt += `\nDescription : \n${get_result.description.replace(/__/g, "_")}`
thumbnail = await getBuffer(get_result.image.large)
await mario4647.sendMessage(from, thumbnail, image, { quoted: ftrol, caption: ini_txt })
break
case 'manga':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/manga?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = `Id : ${get_result.id}\n`
ini_txt += `Id MAL : ${get_result.idMal}\n`
ini_txt += `Title : ${get_result.title.romaji}\n`
ini_txt += `English : ${get_result.title.english}\n`
ini_txt += `Native : ${get_result.title.native}\n`
ini_txt += `Format : ${get_result.format}\n`
ini_txt += `Chapters : ${get_result.chapters}\n`
ini_txt += `Volume : ${get_result.volumes}\n`
ini_txt += `Status : ${get_result.status}\n`
ini_txt += `Source : ${get_result.source}\n`
ini_txt += `Start Date : ${get_result.startDate.day} - ${get_result.startDate.month} - ${get_result.startDate.year}\n`
ini_txt += `End Date : ${get_result.endDate.day} - ${get_result.endDate.month} - ${get_result.endDate.year}\n`
ini_txt += `Genre : ${get_result.genres.join(", ")}\n`
ini_txt += `Synonyms : ${get_result.synonyms.join(", ")}\n`
ini_txt += `Score : ${get_result.averageScore}%\n`
ini_txt += `Characters : \n`
ini_character = get_result.characters.nodes
for (var x of ini_character) {
ini_txt += `- ${x.name.full} (${x.name.native})\n`
}
ini_txt += `\nDescription : ${get_result.description}`
thumbnail = await getBuffer(get_result.coverImage.large)
await mario4647.sendMessage(from, thumbnail, image, { quoted: ftrol, caption: ini_txt })
break
case 'anime':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/anime?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = `Id : ${get_result.id}\n`
ini_txt += `Id MAL : ${get_result.idMal}\n`
ini_txt += `Title : ${get_result.title.romaji}\n`
ini_txt += `English : ${get_result.title.english}\n`
ini_txt += `Native : ${get_result.title.native}\n`
ini_txt += `Format : ${get_result.format}\n`
ini_txt += `Episodes : ${get_result.episodes}\n`
ini_txt += `Duration : ${get_result.duration} mins.\n`
ini_txt += `Status : ${get_result.status}\n`
ini_txt += `Season : ${get_result.season}\n`
ini_txt += `Season Year : ${get_result.seasonYear}\n`
ini_txt += `Source : ${get_result.source}\n`
ini_txt += `Start Date : ${get_result.startDate.day} - ${get_result.startDate.month} - ${get_result.startDate.year}\n`
ini_txt += `End Date : ${get_result.endDate.day} - ${get_result.endDate.month} - ${get_result.endDate.year}\n`
ini_txt += `Genre : ${get_result.genres.join(", ")}\n`
ini_txt += `Synonyms : ${get_result.synonyms.join(", ")}\n`
ini_txt += `Score : ${get_result.averageScore}%\n`
ini_txt += `Characters : \n`
ini_character = get_result.characters.nodes
for (var x of ini_character) {
ini_txt += `- ${x.name.full} (${x.name.native})\n`
}
ini_txt += `\nDescription : ${get_result.description}`
thumbnail = await getBuffer(get_result.coverImage.large)
await mario4647.sendMessage(from, thumbnail, image, { quoted: ftrol, caption: ini_txt })
break
case 'kusonimesearch':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/kusonimesearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = `Title : ${get_result.title}\n`
ini_txt += `Japanese : ${get_result.japanese}\n`
ini_txt += `Genre : ${get_result.genre}\n`
ini_txt += `Seasons : ${get_result.seasons}\n`
ini_txt += `Producers : ${get_result.producers}\n`
ini_txt += `Type : ${get_result.type}\n`
ini_txt += `Status : ${get_result.status}\n`
ini_txt += `Total Episode : ${get_result.total_episode}\n`
ini_txt += `Score : ${get_result.score}\n`
ini_txt += `Duration : ${get_result.duration}\n`
ini_txt += `Released On : ${get_result.released_on}\n`
ini_txt += `Desc : ${get_result.desc}\n`
link_dl = get_result.link_dl
for (var x in link_dl) {
ini_txt += `\n${x}\n`
for (var y in link_dl[x]) {
ini_txt += `${y} - ${link_dl[x][y]}\n`
}
}
ini_buffer = await getBuffer(get_result.thumbnail)
await mario4647.sendMessage(from, ini_buffer, image, { quoted: ftrol, caption: ini_txt })
break
case 'otakudesusearch':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/otakudesusearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = `Title : ${get_result.title}\n`
ini_txt += `Japanese : ${get_result.japanese}\n`
ini_txt += `Judul : ${get_result.judul}\n`
ini_txt += `Type : ${get_result.type}\n`
ini_txt += `Episode : ${get_result.episodes}\n`
ini_txt += `Aired : ${get_result.aired}\n`
ini_txt += `Producers : ${get_result.producers}\n`
ini_txt += `Genre : ${get_result.genres}\n`
ini_txt += `Duration : ${get_result.duration}\n`
ini_txt += `Studios : ${get_result.status}\n`
ini_txt += `Rating : ${get_result.rating}\n`
ini_txt += `Credit : ${get_result.credit}\n`
get_link = get_result.link_dl
for (var x in get_link) {
ini_txt += `\n\n*${get_link[x].title}*\n`
for (var y in get_link[x].link_dl) {
ini_info = get_link[x].link_dl[y]
ini_txt += `\n\`\`\`Reso : \`\`\`${ini_info.reso}\n`
ini_txt += `\`\`\`Size : \`\`\`${ini_info.size}\n`
ini_txt += `\`\`\`Link : \`\`\`\n`
down_link = ini_info.link_dl
for (var z in down_link) {
ini_txt += `${z} - ${down_link[z]}\n`
}
}
}
reply(ini_txt)
break
case 'nhentaisearch':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentaisearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = "Result : \n"
for (var x of get_result) {
ini_txt += `Id : ${x.id}\n`
ini_txt += `Title English : ${x.title_english}\n`
ini_txt += `Title Japanese : ${x.title_japanese}\n`
ini_txt += `Native : ${x.title_native}\n`
ini_txt += `Upload : ${x.date_upload}\n`
ini_txt += `Page : ${x.page}\n`
ini_txt += `Favourite : ${x.favourite}\n\n`
}
reply(ini_txt)
break
case 'nekopoisearch':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Anime Nya Mana\n Contoh: ${prefix + command} Naruto`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/nekopoisearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = ""
for (var x of get_result) {
ini_txt += `Title : ${x.title}\n`
ini_txt += `Link : ${x.link}\n`
ini_txt += `Thumbnail : ${x.thumbnail}\n\n`
}
reply(ini_txt)
break

//=============《 FITUR INFORMATION 》==============//

case 'kbbi':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Yg Mau Dicari Mana Tod\nContoh: ${prefix + command} kursi`)
get_result = await fetchJson(`https://api.lolhuman.xyz/api/kbbi?apikey=${zerokey}&query=${args.join(" ")}`)
lila = get_result.result
ini_txt = `\`\`\`Kata : ${lila[0].nama}\`\`\`\n`
ini_txt += `\`\`\`Kata Dasar : ${lila[0].kata_dasar}\`\`\`\n`
ini_txt += `\`\`\`Pelafalan : ${lila[0].pelafalan}\`\`\`\n`
ini_txt += `\`\`\`Bentuk Tidak Baku : ${lila[0].bentuk_tidak_baku}\`\`\`\n\n`
for (var x of lila) {
ini_txt += `\`\`\`Kode : ${x.makna[0].kelas[0].kode}\`\`\`\n`
ini_txt += `\`\`\`Kelas : ${x.makna[0].kelas[0].nama}\`\`\`\n`
ini_txt += `\`\`\`Artinya : \n${x.makna[0].kelas[0].deskripsi}\`\`\`\n\n`
ini_txt += `\`\`\`Makna Lain : \n${x.makna[0].submakna}\`\`\`\n `
ini_txt += `\`\`\`Contoh Kalimat : \n${x.makna[0].contoh}\`\`\`\n`
}
reply(ini_txt)
break
case 'jarak':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Kotanya Mana Tod\nContoh: ${prefix + command} jakarta - yogyakarta`)
pauls = args.join(" ")
teks1 = pauls.split("-")[0].trim()
teks2 = pauls.split("-")[1].trim()
get_result = await fetchJson(`https://api.lolhuman.xyz/api/jaraktempuh?apikey=${zerokey}&kota1=${teks1}&kota2=${teks2}`)
x = get_result.result
ini_txt = `Informasi Jarak dari ${teks1} ke ${teks2} :\n\n`
ini_txt += `\`\`\`◪ Asal :\`\`\` ${x.from.name}\n`
ini_txt += `\`\`\`◪ Garis Lintang :\`\`\` ${x.from.latitude}\n`
ini_txt += `\`\`\`◪ Garis Bujur :\`\`\` ${x.from.longitude}\n\n`
ini_txt += `\`\`\`◪ Tujuan :\`\`\` ${x.to.name}\n`
ini_txt += `\`\`\`◪ Garis Lintang :\`\`\` ${x.to.latitude}\n`
ini_txt += `\`\`\`◪ Garis Bujur :\`\`\` ${x.to.longitude}\n\n`
ini_txt += `\`\`\`◪ Jarak Tempuh :\`\`\` ${x.jarak}\n`
ini_txt += `\`\`\`◪ Waktu Tempuh :\`\`\`\n`
ini_txt += `   ┌───────────────❏\n`
ini_txt += `❍┤ Kereta Api : ${x.kereta_api}\n`
ini_txt += `❍┤ Pesawat : ${x.pesawat}\n`
ini_txt += `❍┤ Mobil : ${x.mobil}\n`
ini_txt += `❍┤ Motor : ${x.motor}\n`
ini_txt += `❍┤ Jalan Kaki : ${x.jalan_kaki}\n`
ini_txt += `   ╰───────────────❏\n`
reply(ini_txt)
break
case 'wikipedia':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Yg Mau Di Cari Mana Tod\nContoh: ${prefix + command} Tahu`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/wiki?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
reply(get_result)
break
case 'translate':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teks Yg Mau Di Translate Mana Tod\nContoh: ${prefix + command} en Tahu Bacem`)
kode_negara = args[0]
args.shift()
ini_txt = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/translate/auto/${kode_negara}?apikey=${zerokey}&text=${ini_txt}`)
get_result = get_result.result
init_txt = `From : ${get_result.from}\n`
init_txt += `To : ${get_result.to}\n`
init_txt += `Original : ${get_result.original}\n`
init_txt += `Translated : ${get_result.translated}\n`
init_txt += `Pronunciation : ${get_result.pronunciation}\n`
reply(init_txt)
break
case 'jadwaltv':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Channel Nya Mana Tod\nContoh: ${prefix + command} SCTV`)
channel = args[0]
get_result = await fetchJson(`https://api.lolhuman.xyz/api/jadwaltv/${channel}?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Jadwal TV ${channel.toUpperCase()}\n`
for (var x in get_result) {
ini_txt += `${x} - ${get_result[x]}\n`
}
reply(ini_txt)
break
case 'infogempa':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
get_result = await fetchJson(`https://api.lolhuman.xyz/api/infogempa?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Lokasi : ${get_result.lokasi}\n`
ini_txt += `Waktu : ${get_result.waktu}\n`
ini_txt += `Potensi : ${get_result.potensi}\n`
ini_txt += `Magnitude : ${get_result.magnitude}\n`
ini_txt += `Kedalaman : ${get_result.kedalaman}\n`
ini_txt += `Koordinat : ${get_result.koordinat}`
get_buffer = await getBuffer(get_result.map)
await mario4647.sendMessage(from, get_buffer, image, { quoted: ftrol, caption: ini_txt })
break
case 'cuaca':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Kotanya Mana Tod\nContoh: ${prefix + command} Temanggung`)
daerah = args[0]
get_result = await fetchJson(`https://api.lolhuman.xyz/api/cuaca/${daerah}?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Tempat : ${get_result.tempat}\n`
ini_txt += `Cuaca : ${get_result.cuaca}\n`
ini_txt += `Angin : ${get_result.angin}\n`
ini_txt += `Description : ${get_result.description}\n`
ini_txt += `Kelembapan : ${get_result.kelembapan}\n`
ini_txt += `Suhu : ${get_result.suhu}\n`
ini_txt += `Udara : ${get_result.udara}\n`
ini_txt += `Permukaan laut : ${get_result.permukaan_laut}\n`
await mario4647.sendMessage(from, { degreesLatitude: get_result.latitude, degreesLongitude: get_result.longitude }, location, { quoted: ftrol })
reply(ini_txt)
break
case 'covidindo':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
get_result = await fetchJson(`https://api.lolhuman.xyz/api/corona/indonesia?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Positif : ${get_result.positif}\n`
ini_txt += `Sembuh : ${get_result.sembuh}\n`
ini_txt += `Dirawat : ${get_result.dirawat}\n`
ini_txt += `Meninggal : ${get_result.meninggal}`
reply(ini_txt)
break
case 'covidglobal':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
get_result = await fetchJson(`https://api.lolhuman.xyz/api/corona/global?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Positif : ${get_result.positif}\n`
ini_txt += `Sembuh : ${get_result.sembuh}\n`
ini_txt += `Dirawat : ${get_result.dirawat}\n`
ini_txt += `Meninggal : ${get_result.meninggal}`
reply(ini_txt)
break

//=============《 FITUR RANDOM TEXT 》==============//

case 'quotes':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
quotes = await fetchJson(`https://api.lolhuman.xyz/api/random/quotes?apikey=${zerokey}`)
quotes = quotes.result
author = quotes.by
quotes = quotes.quote
reply(`_${quotes}_\n\n*― ${author}*`)
break
case 'quotesanime':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
quotes = await fetchJson(`https://api.lolhuman.xyz/api/random/quotesnime?apikey=${zerokey}`)
quotes = quotes.result
quote = quotes.quote
char = quotes.character
anime = quotes.anime
episode = quotes.episode
reply(`_${quote}_\n\n*― ${char}*\n*― ${anime} ${episode}*`)
break
case 'quotesdilan':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
quotedilan = await fetchJson(`https://api.lolhuman.xyz/api/quotes/dilan?apikey=${zerokey}`)
reply(quotedilan.result)
break
case 'quotesimage':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
get_result = await getBuffer(`https://api.lolhuman.xyz/api/random/${command}?apikey=${zerokey}`)
await mario4647.sendMessage(from, get_result, image, { quotes: ftrol })
break
case 'katabijak':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
get_result = await fetchJson(`https://api.lolhuman.xyz/api/random/${command}?apikey=${zerokey}`)
reply(get_result.result)
break
case 'randomnama':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu = await fetchJson(`https://api.lolhuman.xyz/api/random/nama?apikey=${zerokey}`)
reply(anu.result)
break

//=============《 FITUR SEARCH 》==============//

case 'gimage':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Yg Mau Dicari Mana Tod\nContoh: ${prefix + command} Sandrinna`)
query = args.join(" ")
ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/gimage?apikey=${zerokey}&query=${query}`)
await mario4647.sendMessage(from, ini_buffer, image, { quoted: ftrol })
break
case 'wallpapersearch':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Yg Mau Dicari Mana Tod\nContoh: ${prefix + command} Sandrinna`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/wallpaper?apikey=${zerokey}&query=${query}`)
ini_buffer = await getBuffer(get_result.result)
await mario4647.sendMessage(from, ini_buffer, image, { quoted: ftrol })
break
case 'playstore':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Aplikasinya Mana Tod\nContoh: ${prefix + command} tiktok`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/playstore?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = 'Play Store Search : \n'
for (var x of get_result) {
ini_txt += `Name : ${x.title}\n`
ini_txt += `ID : ${x.appId}\n`
ini_txt += `Developer : ${x.developer}\n`
ini_txt += `Link : ${x.url}\n`
ini_txt += `Price : ${x.priceText}\n`
ini_txt += `Price : ${x.price}\n\n`
}
reply(ini_txt)
break
case 'shopee':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Barang Yg Mau Di Cari Mana Tod\nContoh: ${prefix + command} sepatu`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/shopee?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = 'Shopee Search : \n'
for (var x of get_result) {
ini_txt += `Name : ${x.name}\n`
ini_txt += `Terjual : ${x.sold}\n`
ini_txt += `Stock : ${x.stock}\n`
ini_txt += `Lokasi : ${x.shop_loc}\n`
ini_txt += `Link : ${x.link_produk}\n\n`
}
reply(ini_txt)
break
case 'google':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Nama Yg Mau Cari Mana Tod\nContoh: ${prefix + command} sandrinna`)
query = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/gsearch?apikey=${zerokey}&query=${query}`)
get_result = get_result.result
ini_txt = 'Google Search : \n'
for (var x of get_result) {
ini_txt += `Title : ${x.title}\n`
ini_txt += `Link : ${x.link}\n`
ini_txt += `Desc : ${x.desc}\n\n`
}
reply(ini_txt)
break

//=============《 FITUR PRIMBON 》==============//

case 'artinama':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Namamya Mana Tod\nContoh: ${prefix + command} Mario 4647`)
ini_nama = args.join(" ")
get_result = await fetchJson(`https://api.lolhuman.xyz/api/artinama?apikey=${zerokey}&nama=${ini_nama}`)
reply(get_result.result)
break
case 'jodoh':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Namanya Mana Tod\nContoh: ${prefix + command} Zero & Sandrinna`)
ini_nama = args.join(" ").split("&")
nama1 = ini_nama[0].trim()
nama2 = ini_nama[1].trim()
get_result = await fetchJson(`https://api.lolhuman.xyz/api/jodoh/${nama1}/${nama2}?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Positif : ${get_result.positif}\n`
ini_txt += `Negative : ${get_result.negatif}\n`
ini_txt += `Deskripsi : ${get_result.deskripsi}`
reply(ini_txt)
break
case 'jadian':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Tanggal Jadiannya Mana Tod\nContoh: ${prefix + command} 12 12 2020`)
tanggal = args[0]
bulan = args[1]
tahun = args[2]
get_result = await fetchJson(`https://api.lolhuman.xyz/api/jadian/${tanggal}/${bulan}/${tahun}?apikey=${zerokey}`)
get_result = get_result.result
ini_txt = `Karakteristik : ${get_result.karakteristik}\n`
ini_txt += `Deskripsi : ${get_result.deskripsi}`
reply(ini_txt)
break
case 'tebakumur':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Namanya Mana Tod\nContoh: ${prefix + command} Mario 4647`)
ini_name = args.join(" ")
if (args.length == 0) return reply(`Example: ${prefix + command} LoL Human`)
get_result = await fetchJson(`https://api.lolhuman.xyz/api/tebakumur?apikey=${zerokey}&name=${ini_name}`)
get_result = get_result.result
ini_txt = `Nama : ${get_result.name}\n`
ini_txt += `Umur : ${get_result.age}`
reply(ini_txt)
break

//=============《 FITUR STALK 》==============//

case 'stalkig':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Usernamenya Mana Tod\nContoh: ${prefix + command} Sandrinna_11`)
username = args[0]
ini_result = await fetchJson(`https://api.lolhuman.xyz/api/stalkig/${username}?apikey=${zerokey}`)
ini_result = ini_result.result
ini_buffer = await getBuffer(ini_result.photo_profile)
ini_txt = `Username : ${ini_result.username}\n`
ini_txt += `Full Name : ${ini_result.fullname}\n`
ini_txt += `Posts : ${ini_result.posts}\n`
ini_txt += `Followers : ${ini_result.followers}\n`
ini_txt += `Following : ${ini_result.following}\n`
ini_txt += `Bio : ${ini_result.bio}`
mario4647.sendMessage(from, ini_buffer, image, { caption: ini_txt })
break
case 'stalktiktok':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Usernamenya Mana Tod\nContoh: ${prefix + command} Sandrinna`)
stalk_toktok = args[0]
get_result = await fetchJson(`https://api.lolhuman.xyz/api/stalktiktok/${stalk_toktok}?apikey=mario4647`)
get_result = get_result.result
ini_txt = `Username : ${get_result.username}\n`
ini_txt += `Nickname : ${get_result.nickname}\n`
ini_txt += `Bio : ${get_result.nickname}\n`
ini_txt += `Followers : ${get_result.followers}\n`
ini_txt += `Followings : ${get_result.followings}\n`
ini_txt += `Likes : ${get_result.likes}\n`
ini_txt += `Video : ${get_result.video}\n`
pp_tt = await getBuffer(get_result.user_picture)
mario4647.sendMessage(from, pp_tt, image, { quoted: ftrol, caption: ini_txt })
break
case 'stalkgithub':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Usernamenya Mana Tod\nContoh: ${prefix + command} Zero-YT7`)
username = args[0]
ini_result = await fetchJson(`https://api.lolhuman.xyz/api/github/${username}?apikey=${zerokey}`)
ini_result = ini_result.result
ini_buffer = await getBuffer(ini_result.avatar)
ini_txt = `Name : ${ini_result.name}\n`
ini_txt += `Link : ${ini_result.url}\n`
ini_txt += `Public Repo : ${ini_result.public_repos}\n`
ini_txt += `Public Gists : ${ini_result.public_gists}\n`
ini_txt += `Followers : ${ini_result.followers}\n`
ini_txt += `Following : ${ini_result.following}\n`
ini_txt += `Bio : ${ini_result.bio}`
mario4647.sendMessage(from, ini_buffer, image, { caption: ini_txt })
break

//=============《 FITUR RANDOM IMAGE 》==============//

case 'art':
case 'bts':
case 'exo':
case 'elf':
case 'loli':
case 'neko':
case 'waifu':
case 'shota':
case 'husbu':
case 'sagiri':
case 'shinobu':
case 'megumin':
case 'wallnime':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
getBuffer(`https://api.lolhuman.xyz/api/random/${command}?apikey=${zerokey}`).then((gambar) => {
sticWait(from)
mario4647.sendMessage(from, gambar, image, { quoted: ftrol, caption: 'Nih  © Mario 4647'})
})
break
case 'chiisaihentai':
case 'trap':
case 'blowjob':
case 'yaoi':
case 'ecchi':
case 'hentai':
case 'ahegao':
case 'hololewd':
case 'sideoppai':
case 'animefeets':
case 'animebooty':
case 'animethighss':
case 'animearmpits':
case 'hentaifemdom':
case 'lewdanimegirls':
case 'biganimetiddies':
case 'hentai4everyone':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
await getBuffer(`https://api.lolhuman.xyz/api/random/nsfw/${command}?apikey=${zerokey}`).then((gambar) => {
sticWait(from)
mario4647.sendMessage(from, gambar, image, { quoted: ftrol, caption: 'Nih  © Mario 4647'})
})
break

//=============《 FITUR ASUPAN 》==============//

case 'asupan':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.result)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupancecan':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/cecan?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupanhijaber':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/hijaber?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupansantuy':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/santuy?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupanukhti':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/ukty?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupanbocil':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/bocil?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupanghea':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/ghea?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'asupanrika':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
ini = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/asupan/rikagusriani?apikey=${zerkey}`)
sticWait(from)
buffer = await getBuffer(ini.result.url)
mario4647.sendMessage(from, buffer, video, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break

//=============《 FITUR CECAN 》==============//

case 'cecanvietnam':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
huft = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/cewe/vietnam?apikey=${zerkey}`)
sticWait(from)
goo = await getBuffer(huft.result.url)
mario4647.sendMessage(from, goo, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'cecanmalaysia':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
huft = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/cewe/malaysia?apikey=${zerkey}`)
sticWait(from)
goo = await getBuffer(huft.result.url)
mario4647.sendMessage(from, goo, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'cecankorea':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
huft = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/cewe/korea?apikey=${zerkey}`)
sticWait(from)
goo = await getBuffer(huft.result.url)
mario4647.sendMessage(from, goo, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'cecanindonesia':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
huft = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/cewe/indonesia?apikey=${zerkey}`)
sticWait(from)
goo = await getBuffer(huft.result.url)
mario4647.sendMessage(from, goo, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'cecanjapan':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
huft = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/cewe/japan?apikey=${zerkey}`)
sticWait(from)
goo = await getBuffer(huft.result.url)
mario4647.sendMessage(from, goo, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break
case 'cecanthailand':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
huft = await fetchJson(`https://zeroyt7-api.herokuapp.com/api/cewe/thailand?apikey=${zerkey}`)
sticWait(from)
goo = await getBuffer(huft.result.url)
mario4647.sendMessage(from, goo, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
break

//=============《 FITUR RANDOM MEME 》==============//

case 'randommeme':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
await getBuffer(`https://api.lolhuman.xyz/api/random/meme?apikey=${zerokey}`).then((gambar) => {
sticWait(from)
mario4647.sendMessage(from, gambar, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
})
break
case 'randomdarkjoke':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
await getBuffer(`https://api.lolhuman.xyz/api/meme/darkjoke?apikey=${zerokey}`).then((gambar) => {
sticWait(from)
mario4647.sendMessage(from, gambar, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
})
break
case 'randommemeindo':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
await getBuffer(`https://api.lolhuman.xyz/api/meme/memeindo?apikey=${zerokey}`).then((gambar) => {
sticWait(from)
mario4647.sendMessage(from, gambar, image, {quoted: ftrol, caption: 'Nih  © Mario 4647'})
})
break
//==============《 FITUR SHOP 》==============//

case 'dmml':
qris = fs.readFileSync('./arabotz/ara.jpg')
trans = `©Created : Mario 4647`
list = `🌸Price List Diamond ML🌸
86dm = Idr 20.000
172dm = Idr 40.000
257dm = Idr 60.000
344dm = Idr 80.000
429dm = Idr 100.000
514dm =  Idr 117.000
600dm = Idr 136.000
706dm = Idr 155.000
878dm = Idr 195.000
963dm = Idr 215.000
1050dm = Idr 233.000

Silahkan Pilih Metode Pembayaran
Dibawah Ini`
but = [
          { buttonId: `${prefix}gopay`, buttonText: { displayText: 'GOPAY' }, type: 1 },
          { buttonId: `${prefix}ovo`, buttonText: { displayText: 'OVO' }, type: 1 },
          { buttonId: `${prefix}dana`, buttonText: { displayText: 'DANA' }, type: 1 }
        ]
sendButImage(from, list, trans, qris, but)
break
case 'dmff':
qris = fs.readFileSync('./arabotz/ara.jpg')
trans = `©Created : Mario 4647`
list = `🌸Price List Diamond FF🌸
70dm = Idr 10.000
100dm = Idr 15.000
140dm = Idr 20.000
210dm = Idr 30.000
355dm = Idr 50.000
500dm =  Idr 67.000
720dm = Idr 95.000
1000dm = Idr 130.000
1075dm = Idr 140.000
2000dm = Idr 250.000
7290dm = Idr 910.000

Silahkan Pilih Metode Pembayaran
Dibawah Ini`
but = [
          { buttonId: `${prefix}gopay`, buttonText: { displayText: 'GOPAY' }, type: 1 },
          { buttonId: `${prefix}ovo`, buttonText: { displayText: 'OVO' }, type: 1 },
          { buttonId: `${prefix}dana`, buttonText: { displayText: 'DANA' }, type: 1 }
        ]
sendButImage(from, list, trans, qris, but)
break
case 'ucpubg':
qris = fs.readFileSync('./arabotz/ara.jpg')
trans = `©Created : Mario 4647`
list = `🌸Price List Uc Pubg🌸
36uc = Idr 10.000
73uc = Idr 15.000
221uc = Idr 45.000
770uc = Idr 140.000
2013uc = Idr 340.000
4200uc =  Idr 670.000
8750uc = Idr 1.340.000

Silahkan Pilih Metode Pembayaran
Dibawah Ini`
but = [
          { buttonId: `${prefix}gopay`, buttonText: { displayText: 'GOPAY' }, type: 1 },
          { buttonId: `${prefix}ovo`, buttonText: { displayText: 'OVO' }, type: 1 },
          { buttonId: `${prefix}dana`, buttonText: { displayText: 'DANA' }, type: 1 }
        ]
sendButImage(from, list, trans, qris, but)
break

//=============《 FITUR INFO 》==============//
case 'jadibot':
if (!isOwner) return sticOwner(from).
mario4647.version = [2, 2143, 8]
mario4647.browserDescription = ['Mario4647','Safari','3.0']
if (args[0] && args[0].length > 200) {
	let json = Buffer.from(args[0], 'base64').toString('utf-8')
    let obj = JSON.parse(json)
    await mario4647.loadAuthInfo(obj)
}
try {
mario4647.on('qr' ,async qr => {
qrbot = await qrkode.toDataURL(qr, { scale: 8 })
buffqr = await Buffer.from(qrbot.split('data:image/png;base64,')[1], 'base64')
await fs.writeFileSync(`./jadibot@${sender}.jpg`, buffqr)
let scen = await mario4647.sendMessage(from, fs.readFileSync(`./jadibot@${sender}.jpg`), MessageType.image, {quoted : mek,caption: 'Scan QR ini untuk jadi bot sementara!\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk WhatsApp Web\n3. Scan QR ini \n\nQR Expired dalam 20 detik'})    
setTimeout(() => {
       mario4647.deleteMessage(from, scen.key)
  }, 30000);
})  
mario4647.on ('open', async () => {
  console.log ('credentials update')
  const authInfo = mario4647.base64EncodedAuthInfo()
  fs.writeFileSync(`./sampah/${sender}.json`, JSON.stringify(authInfo  ,null, '\t'))
  await mario4647.sendMessage('0@s.whatsapp.net', `Kamu bisa login tanpa qr dengan pesan dibawah ini`, MessageType.extendedText)
  mario4647.sendMessage('0@s.whatsapp.net', `${prefix + command} ${Buffer.from(JSON.stringify(authInfo)).toString('base64')}`, MessageType.extendedText)
})
mario4647.on('chat-update', async (chat) => {
	require('./ara.js')(mario4647, chat)
})    
await mario4647.connect().then(async ({user}) => {
reply('Berhasil tersambung dengan WhatsApp - mu.\n*NOTE: Ini cuma numpang*\n' + JSON.stringify(user, null, 2))
})
} catch {
reply('Error! hanya 1 orang yang dapat mengakses fitur jadibot')
}
break
case 'stopjadibot':
if (!isOwner) return sticOwner(from)
try {
reply('Oke')
fs.unlinkSync(`./sampah/${sender}.json`)
mario4647.close()
} catch {
reply('Oke')
mario4647.close()
}
break
case 'info':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
teks =
`┏━➤ *『INFO BOTZ』*
┃┃✯ Nama Bot : ARA BOTZ
┃┃✯ Creator : ${creator}
┃┃✯ Recode : ${recode}
┃┃✯ Prefix : *『> ${prefix} <』*
┃┃✯ Platform : Java Script
┃┃✯ Runtime : ${runtime(process.uptime())}
┃┃✯ Sc Bot : Chat Owner
┗━━━━━━━`
gam = fs.readFileSync('./arabotz/ara.jpg')
but = [
          { buttonId: `${prefix}menu`, buttonText: { displayText: 'BACK TO MENU🌸' }, type: 1 },
          { buttonId: `${prefix}donasi`, buttonText: { displayText: 'DONASI🌸' }, type: 1 },
          { buttonId: `${prefix}owner`, buttonText: { displayText: 'OWNER🌸' }, type: 1 }
        ]
        sendButImage(from, teks, "© Mario 4647", gam, but)
break
case 'sc':
case 'sourcecode':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu =`
*┌─❒ SCRIPT ❒*
*│* ◦➛Base : ${creator}
*│* ◦➛Recode : ${recode}
*│* 
*└──────[ INFO ]──────❒*
  *│* Sc Ini Gua Enc Beberapa
  *│* Untuk Menghindari Jual Beli
  *│* Mau Sc Nya?
  *│* Chat Owner Ae
  *└──────────────────❒*`
but = [
{ buttonId: `${prefix}menu`, buttonText: { displayText: 'BACK TO MENU🌸' }, type: 1 },
{ buttonId: `${prefix}sewabot`, buttonText: { displayText: 'SEWA BOT🌸' }, type: 1 },
{ buttonId: `${prefix}owner`, buttonText: { displayText: 'OWNER🌸' }, type: 1 }
]
sendButton(from, anu, faketeks, but, mek)
break
case 'sewabot':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
teks =
`*ARA BOTZ SHOP🍁*

\`\`\`LIST SEWA BOT🤖

 ~ BOT GG🤖 ~

~1 HARI = FREE
~1 MINGGU = 2K
~1 BULAN = 5K
~PERMANEN + PREMIUM = 10K

~ BOT PASARAN 🤖~

~1 HARI = FREE
~1 MINGGU = 1K
~1 BULAN = 2,5K
~PERMANEN = 5K

~ SC BOT 🗃️~

ENCRYPT = 10K
DECRYPT = 50K

~ RDP/VPS 🖥️~

RDP RAM 2 CPU v1 = 20K
RDP RAM 4 CPU v1 = 45K
RDP RAM 8 CPU v2
= 85K

VPS RAM 2 CPU v1 = 25K
VPS RAM 4 CPU v1 = 45K
VPS RAM 8 CPU v2
= 95K

NB:RDP FULL GARANSI JIKA TIDAK MELANGGAR T.O.S,JIKA AKUN RDP TER SUSPEND KARENA MELANGGAR T.O.S(RULES) MAKA TIDAK ADA GARANSI DAN ADMIN TIDAK BERTANGGUNG JAWAB\`\`\`

*《MARIO 4647》*
https://wa.me/+6282110232966?text=Bang+Mau+Beli+Kebutuhan+Bot+Nya`
gam = fs.readFileSync('./arabotz/ara2.jpg')
but = [
          { buttonId: `${prefix}gopay`, buttonText: { displayText: 'GOPAY' }, type: 1 },
          { buttonId: `${prefix}dana`, buttonText: { displayText: 'DANA' }, type: 1 },
          { buttonId: `${prefix}ovo`, buttonText: { displayText: 'OVO' }, type: 1 }
        ]
        sendButImage(from, teks, "©Mario 4647🍁", gam, but)
break
case 'gopay':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
but = [
{ buttonId: `${prefix}owner`, buttonText: { displayText: 'DONE' }, type: 1 }
]
sendButton(from, `GOPAY : ${gopay}`, faketeks, but, mek)
break
case 'dana':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
but = [
{ buttonId: `${prefix}owner`, buttonText: { displayText: 'DONE' }, type: 1 }
]
sendButton(from, `DANA : ${dana}`, faketeks, but, mek)
break
case 'ovo':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
but = [
{ buttonId: `${prefix}owner`, buttonText: { displayText: 'DONE' }, type: 1 }
]
sendButton(from, `OVO : ${ovo}`, faketeks, but, mek)
break
case "runtime":
case "test":
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
run = process.uptime();
teks = `${kyun(run)}`;
reply(teks);
break;
case "speed":
case "ping":
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
const timestamp = speed();
const latensi = speed() - timestamp;
exec(`neofetch --stdout`, (error, stdout, stderr) => {
const child = stdout.toString("utf-8");
const ssd = child.replace(/Memory:/, "Ram:");
const pingnya = `*${ssd}Speed: ${latensi.toFixed(4)} Second*`;
reply(pingnya);
});
break;
case 'verify':
const ara = fs.readFileSync('./sticker/anime/verify.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
const serialUser = createSerial(18)
veri = sender
_registered.push(sender)
fs.writeFileSync('./database/registered.json', JSON.stringify(_registered))
addRegisteredUser(sender, serialUser)
const kimak = 
`Terima Kasih Telah Mendaftarkan
Ke Database ${botname}${logo}
Silahkan Gunakan Bot Dengan Bijak

*┌─* ❒ 「 VERIFY 」 ❒
*├* Nama : ${pushname}
*├* Nomor : @${sender.split('@')[0]}
*├* Seri: ${serialUser}
*├* Pengguna: ${_registered.length}
*└*❏`
gam = fs.readFileSync('./arabotz/ara2.jpg')
but = [
          { buttonId: `${prefix}menu`, buttonText: { displayText: 'MENU🔖' }, type: 1 },
          { buttonId: `${prefix}donasi`, buttonText: { displayText: 'DONASI🔖' }, type: 1 },
          { buttonId: `${prefix}owner`, buttonText: { displayText: 'OWNER🔖' }, type: 1 }
        ]
        sendButImage(from, kimak, "© Mario 4647", gam, but)
break
case 'donasi':
teks = `Mau Donasi Apa Liat Doank ?
Klo Mau Donasi Pilih Aja Di Bawah

Makasih Kalo Mau Donasi Beneran
Semoga Rejekinya Tambah Lancar Amin

    ┌───────────────❏
❍┤ヅ Gopay : ${gopay}
❍┤ヅ Dana : ${dana}
❍┤ヅ Ovo : ${ovo}
    ╰───────────────❏`
gam = fs.readFileSync('./arabotz/ara2.jpg')
but = [
          { buttonId: `${prefix}menu`, buttonText: { displayText: 'BACK TO MENU🔖' }, type: 1 },
          { buttonId: `${prefix}info`, buttonText: { displayText: 'INFO🔖' }, type: 1 },
          { buttonId: `${prefix}owner`, buttonText: { displayText: 'OWNER🔖' }, type: 1 }
        ]
        sendButImage(from, teks, "© Mario 4647", gam, but)
break

//=============《 FITUR MAKER 》==============//

case 'blackpink':
case 'neon':
case 'greenneon':
case 'advanceglow':
case 'futureneon':
case 'sandwriting':
case 'sandsummer':
case 'sandengraved':
case 'metaldark':
case 'neonlight':
case 'holographic':
case 'text1917':
case 'minion':
case 'deluxesilver':
case 'newyearcard':
case 'bloodfrosted':
case 'halloween':
case 'jokerlogo':
case 'fireworksparkle':
case 'natureleaves':
case 'bokeh':
case 'toxic':
case 'strawberry':
case 'box3d':
case 'roadwarning':
case 'breakwall':
case 'icecold':
case 'luxury':
case 'cloud':
case 'summersand':
case 'horrorblood':
case 'thunder':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teksnya Mana ?\nContoh: ${prefix + command} Mario 4647`)
ini_txt = args.join(" ")
getBuffer(`https://api.lolhuman.xyz/api/textprome/${command}?apikey=${zerokey}&text=${ini_txt}`).then((gambar) => {
mario4647.sendMessage(from, gambar, image, { quoted: ftrol })
})
break

//=============《 FITUR GAME 》==============//

case 'truth':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
const trut =['Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buatmu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
const ttrth = trut[Math.floor(Math.random() * trut.length)]
truteh = await getBuffer(`https://i.ibb.co/rdyFbvf/20211019-073936.jpg`)
mario4647.sendMessage(from, truteh, image, { caption: '*TRUTH*\n\n'+ ttrth, quoted: ftrol })
break
case 'dare':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
const dare =['Kirim pesan ke mantan kamu dan bilang "aku masih suka sama kamu','telfon crush/pacar sekarang dan ss ke pemain','pap ke salah satu anggota grup','Bilang "KAMU CANTIK BANGET NGGAK BOHONG" ke cowo','ss recent call whatsapp','drop emot "ðŸ¦„??" setiap ngetik di gc/pc selama 1 hari','kirim voice note bilang can i call u baby?','drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu','pake foto sule sampe 3 hari','ketik pake bahasa daerah 24 jam','ganti nama menjadi "gue anak lucinta luna" selama 5 jam','chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia "i lucky to hv you','prank chat mantan dan bilang " i love u, pgn balikan','record voice baca surah al-kautsar','bilang "i hv crush on you, mau jadi pacarku gak?" ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini','sebutkan tipe pacar mu!','snap/post foto pacar/crush','teriak gajelas lalu kirim pake vn kesini','pap mukamu lalu kirim ke salah satu temanmu','kirim fotomu dengan caption, aku anak pungut','teriak pake kata kasar sambil vn trus kirim kesini','teriak " gw wibu sejati " di depan rumah mu','ganti nama jadi " BOWO " selama 24 jam','Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll']
const der = dare[Math.floor(Math.random() * dare.length)]
tod = await getBuffer(`https://i.ibb.co/rdyFbvf/20211019-073936.jpg`)
mario4647.sendMessage(from, tod, image, { quoted: ftrol, caption: '*DARE*\n\n'+ der })
break
case 'tebakkalimat':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu = await fetchJson(`https://velgrynd.herokuapp.com/api/tebak/kalimat`, {method: 'get'})
get = `*${anu.result.soal}*`
setTimeout( () => {
mario4647.sendMessage(from, 'Jawaban: '
+anu.result.jawaban, text, {quoted: ftrol})
}, 60000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_10 Detik lagi..._', text)
}, 50000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_20 Detik lagi..._', text)
}, 40000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_30 Detik lagi..._', text)
}, 30000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_40 Detik lagi..._', text)
}, 20000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_50 Detik lagi..._', text)
}, 10000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_60 Detik lagi..._', text)
}, 2500) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, get, text, {quoted: ftrol})
}, 0) // 1000 = 1s,
break
case 'tebaktebakan':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu = await fetchJson(`https://velgrynd.herokuapp.com/api/tebak/tebakan`, {method: 'get'})
get = `*${anu.result.soal}*`
setTimeout( () => {
mario4647.sendMessage(from, 'Jawaban: '
+anu.result.jawaban, text, {quoted: ftrol}) 
}, 60000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_10 Detik lagi..._', text) 
}, 50000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_20 Detik lagi..._', text) 
}, 40000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_30 Detik lagi..._', text)
}, 30000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_40 Detik lagi..._', text) 
}, 20000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_50 Detik lagi..._', text) 
}, 10000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_60 Detik lagi..._', text)
}, 2500) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, get, text, {quoted: ftrol})
}, 0) // 1000 = 1s,
break
case 'tebaklirik':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu = await fetchJson(`https://velgrynd.herokuapp.com/api/tebak/lirik`, {method: 'get'})
get = `*${anu.result.question}*`
setTimeout( () => {
mario4647.sendMessage(from, 'Jawaban: '
+anu.result.answer, text, {quoted: ftrol}) 
}, 60000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_10 Detik lagi..._', text) 
}, 50000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_20 Detik lagi..._', text) 
}, 40000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_30 Detik lagi..._', text) 
}, 30000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_40 Detik lagi..._', text) 
}, 20000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_50 Detik lagi..._', text) 
}, 10000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_60 Detik lagi..._', text) 
}, 2500) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, get, text, {quoted: ftrol})
}, 0) // 1000 = 1s,
break
case 'tebakkimia':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu = await fetchJson(`https://velgrynd.herokuapp.com/api/tebak/kimia`, {method: 'get'})
get = `*${anu.result.nama}*`
setTimeout( () => {
mario4647.sendMessage(from, 'Jawaban: '
+anu.result.lambang, text, {quoted: ftrol}) 
}, 60000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_10 Detik lagi..._', text) 
}, 50000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_20 Detik lagi..._', text)
}, 40000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_30 Detik lagi..._', text)
}, 30000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_40 Detik lagi..._', text)
}, 20000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_50 Detik lagi..._', text) 
}, 10000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_60 Detik lagi..._', text) 
}, 2500) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, get, text, {quoted: ftrol}) 
}, 0) // 1000 = 1s,
break
case 'tebakjenaka':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
anu = await fetchJson(`https://velgrynd.herokuapp.com/api/tebak/jenaka`, {method: 'get'})
tebakjenaka = `*${anu.result.pertanyaan}*`
setTimeout( () => {
mario4647.sendMessage(from, 'Jawaban: '
+anu.result.jawaban, text, {quoted: ftrol}) 
}, 60000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_10 Detik lagi..._', text) 
}, 50000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_20 Detik lagi..._', text) 
}, 40000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_30 Detik lagi..._', text) 
}, 30000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_40 Detik lagi..._', text) 
}, 20000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_50 Detik lagi..._', text) 
}, 10000) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, '_60 Detik lagi..._', text) 
}, 2500) // 1000 = 1s,
setTimeout( () => {
mario4647.sendMessage(from, tebakjenaka, text, {quoted: ftrol}) 
}, 0) // 1000 = 1s,
break
case 'tebakgambar':
if (tebakgambar.hasOwnProperty(sender.split('@')[0])) return reply("Selesein yg sebelumnya dulu atuh")
  get_result = await fetchJson(`https://api.lolhuman.xyz/api/tebak/gambar?apikey=KurrXd`)
get_result = get_result.result
ini_image = get_result.image
jawaban = get_result.answer
ini_buffer = await getBuffer(ini_image)
kisi_kisi = jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '_')
buff = await getBuffer(ini_image)

mario4647.sendMessage(from, ini_buffer, image, { quoted: mek, caption: 'Silahkan jawab soal berikut ini\n\nPetunjuk :tebak sendirilah kontol\nWaktu : 30s' }).then(() => {
  tebakgambar[sender.split('@')[0]] = jawaban.toLowerCase()
  fs.writeFileSync("./database/tebakgambar.json", JSON.stringify(tebakgambar))
})
await sleep(30000)
if (tebakgambar.hasOwnProperty(sender.split('@')[0])) {
  console.log(color("Jawaban: " + jawaban))
  titid = "*Jawaban*: " + jawaban
  sendButMessage(from, titid, `Klik Untuk Ke Game Selanjutnya`, [
  {
 buttonId: `tebakgambar`,
 buttonText: {
displayText: `⬡ NEXT `,
 },
 type: 1,
  },]);

  delete tebakgambar[sender.split('@')[0]]
  fs.writeFileSync("./database/tebakgambar.json", JSON.stringify(tebakgambar))
}
gameAdd(sender, glimit)
break
case 'tembak':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (args.length == 0) return reply(`Teksnya Mana ?\nContoh: ${prefix + command} udara / darat / laut`)
if (args[0] == 'udara') {
setTimeout( () => {
reply(`[ *PERINTAH DILAKSANAKAN* ]`)
}, 1000)
setTimeout( () => {
reply(`[ *SEDANG BERBURU* ]`)
}, 5000)
setTimeout( () => {
reply(`[ *SUKSES !! DAN ANDA MENDAPATKAN* ]`)
}, 8000)
setTimeout( () => {
reply(`[ *WOW ANDA MENDAPATKAN* ]\n[ *${buruh33}* ]`)
}, 12000)
}
if (args[0] == 'darat') {
setTimeout( () => {
reply(`[ *PERINTAH DILAKSANAKAN* ]`)
}, 1000)
setTimeout( () => {
reply(`[ *SEDANG BERBURU* ]`)
}, 5000)
setTimeout( () => {
reply(`[ *SUKSES !! DAN ANDA MENDAPATKAN* ]`)
}, 8000)
setTimeout( () => {
reply(`[ *WOW ANDA MENDAPATKAN* ]\n[ *${buruh22}* ]`)
}, 12000)
}
if (args[0] == 'laut') {
setTimeout( () => {
reply(`[ *PERINTAH DILAKSANAKAN* ]`)
}, 1000)
setTimeout( () => {
reply(`[ *SEDANG BERBURU* ]`)
}, 5000)
setTimeout( () => {
reply(`[ *SUKSES !! DAN ANDA MENDAPATKAN* ]`)
}, 8000)
setTimeout( () => {
reply(`[ *WOW ANDA MENDAPATKAN* ]\n[ *${buruh11}* ]`)
}, 12000)
}
break
case 'slot':
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
const somtoy = sotoy[Math.floor(Math.random() * sotoy.length)]
const somtoy2 = sotoy1[Math.floor(Math.random() * sotoy1.length)]
const somtoy3 = sotoy2[Math.floor(Math.random() * sotoy2.length)]
const somtoy4 = sotoy3[Math.floor(Math.random() * sotoy3.length)]
mario4647.sendMessage(from, `
[ SLOTS ]\n-----------------
${somtoy2}
${somtoy}<=====
${somtoy3}
[ SLOTS ]
Keterangan : Jika anda Mendapatkan 3 Buah Sama Berarti Kamu Win
Contoh : ${somtoy4}<=====`, text, { quoted: ftrol })
break


//=============《 FITUR 18+ 》==============//

case 'bokep1':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/h2nygxbyb6n9cyo/VID-20210107-WA1468.mp4/file' })
break
case 'bokep2':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/pk8hozohzdc076c/VID-20210107-WA1466.mp4/file' })
break
case 'bokep3':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/112q3u286tnvzjo/VID-20210107-WA1467.3gp/file' })
break
case 'bokep4':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/arpphhxsv94ak0r/VID-20210107-WA1462.mp4/file' })
break
case 'bokep5':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/us3f4j62emftbrf/VID-20210107-WA1463.mp4/file' })
break
case 'bokep6':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/v4033tkl16hgf2b/VID-20210107-WA1459.mp4/file' })
break
case 'bokep7':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/3scnim6d1x4b8ie/VID-20210107-WA1461.mp4/file' })
break
case 'bokep8':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/dx9tklonu0eq36w/VID-20210107-WA1464.mp4/file' })
break
case 'bokep9':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/snwja297dv4zvtl/VID-20210107-WA0036.mp4/file' })
break
case 'bokep10':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/60dqek0mqhyt6rn/VID-20210107-WA1530.mp4/file' })
break
case 'bokep11':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/ni2mcdknb6zn50t/VID-20210107-WA1532.mp4/file' })
break
case 'bokep12':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/i9t96lrmd9lm71z/VID-20210107-WA1542.mp4/file' })
break
case 'bokep13':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/tjqdfmp8g08dt4e/VID-20210107-WA1536.mp4/file' })
break
case 'bokep14':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/x034q0s16u9vyhy/VID-20210107-WA1537.mp4/file' })
break
case 'bokep15':				 
if (!isRegistered) return sendButRegis(from, daftar1, daftar2, daftar3, { quoted: ftrol})
if (isPremium) return reply(`*PREMIUM USER ONLY「❗」*`)
qute = fs.readFileSync('./arabotz/ara.jpg') 
mario4647.sendMessage(from, qute, image, { quoted: ftrol, caption: '*NIH BAHAN COLI BUAT KALIAN :v*\nLink Download \n\nhttps://www.mediafire.com/file/mgmynqghjnon2q7/VID-20210107-WA1533.mp4/file' })
break

//======================[FITUR UPSW]====================//

case 'upswteks':
if (!isOwner) return reply('LU BUKAN OWNER GBLOK')
if (args.length < 1) return reply('Teksnya?')
teks = body.slice(10)
mario4647.sendMessage('status@broadcast', teks, MessageType.text)
reply(`Sukses upload status:\n${teks}`)
break
case 'upswsticker':
if (!isOwner) return reply('LU BUKAN OWNER GBLOK')
if (!isQuotedSticker) return reply('Reply stikernya!')
if (isMedia && !mek.message.videoMessage || isQuotedSticker) {
const encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
buff = await mario4647.downloadMediaMessage(encmedia)
mario4647.sendMessage('status@broadcast', buff, sticker)
}
reply(`Sukses upload sticker`)
break
case 'upswaudio':
if (!isOwner) return reply('LU BUKAN OWNER GBLOK')
if (!isQuotedAudio) return reply('Reply audionya!')
if (isMedia && !mek.message.videoMessage || isQuotedAudio) {
const encmedia = isQuotedAudio ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
buff = await mario4647.downloadMediaMessage(encmedia)
mario4647.sendMessage('status@broadcast', buff, audio, {mimetype: 'audio/mp4', duration: 359996400})
}
reply(`Sukses upload audio`)
break
case 'upswvideo':
if (!isOwner) return reply('LU BUKAN OWNER GBLOK')
var konti = body.slice(11)
sticWait(from)
var enmediap = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
var mediap = await mario4647.downloadAndSaveMediaMessage(enmediap)
const buffer3 = fs.readFileSync(mediap)
mario4647.sendMessage('status@broadcast', buffer3, MessageType.video, {duration: 359996400, caption: `${konti}`})
reply(`Sukses upload video:\n${konti}`)
break
case 'upswimage':
if (!isOwner) return reply('LU BUKAN OWNER GBLOK')
var teksyy = body.slice(11)
sticWait(from)
enmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
media = await mario4647.downloadAndSaveMediaMessage(enmedia)
buffer = fs.readFileSync(media)
mario4647.sendMessage('status@broadcast', buffer, MessageType.image, {quoted: mek, caption: `${teksyy}`})
reply(`Sukses upload image:\n${teksyy}`)
break

//=============《 AKHIR SEMUA FITUR 》==============//

if (hour_now >= '02:00' && hour_now <= '04:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Waktunya sahur kak, Main botnya buat nanti lagi, Sebelum makan jangan lupa baca Doa ya kak', 'yellow'), color('(😊)', 'white'))
          }
        if (hour_now >= '04:00' && hour_now <= '05:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Bentar lagi jam 5 nih kak, Jangan lupa sholat subuh ya kak', 'yellow'), color('(😊)', 'white'))
          }
          if (hour_now >= '05:00' && hour_now <= '06:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Udah sholat Subuh belum kak', 'yellow'), color('(🙄)', 'white'))
          }
        if (hour_now >= '06:00' && hour_now <= '11:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Pagi kak, Jangan lupa mandi', 'yellow'), color('(😅)', 'white'))
          }
          if (hour_now >= '11:00' && hour_now <= '12:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Siang kak, Dah mandi blm kak?', 'yellow'), color('(🙄)', 'white'))
          }
          if (hour_now >= '12:00' && hour_now <= '14:00') {
           console.log(color('[Pesan Bot]', 'cyan'), color('Dah jam 12 kak, Jangan lupa sholat Dzuhur ya kak', 'yellow'), color('(😊)', 'white'))
           }
        if (hour_now >= '14:00' && hour_now <= '15:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Sore kak, Jangan lupa mandi', 'yellow'), color('(😅)', 'white'))
          }
        if (hour_now >= '15:00' && hour_now <= '16:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Dah jam 3 kak, Jangan lupa sholat Ashar ya kak', 'yellow'), color('(😊)', 'white'))
          }
        if (hour_now >= '17:00' && hour_now <= '18:00') {
          console.log(color('[Pesan Bot]', 'cyan'), color('Bentar lagi buka kak, Sabar ya kak', 'yellow'), color('(😆)', 'white'))
          }
        if (hour_now >= '18:00' && hour_now <= '19:00') {
        	console.log(color('[Pesan Bot]', 'cyan'), color('Alhamdulillah, Dh magrib jan lupa sholat kak', 'yellow'), color('(😊)', 'white'))
        }
        if (hour_now >= '19:00' && hour_now <= '20:00') {
           console.log(color('[Pesan Bot]', 'cyan'), color('Bentar lagi jam 8 gak mabar kak?', 'yellow'), color('(😊)', 'white'))
           }
        if (hour_now >= '20:00' && hour_now <= '00:00') {
           console.log(color('[Pesan Bot]', 'cyan'), color('Selamat malam kak, Jangan begadang ya kak, Tar sakit loh', 'yellow'), color('(😄)', 'white'))
        }
          if (hour_now >= '00:00' && hour_now <= '02:00') {
           console.log(color('[Pesan Bot]', 'cyan'), color('Bot ngantuk kak, tidur dulu ya kak', 'yellow'), color('(😴)', 'white'))
        }
if (budy.includes(`Mastah`)) {
const ara = fs.readFileSync('./sticker/anime/mastah.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`mastah`)) {
const ara = fs.readFileSync('./sticker/anime/mastah.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`Ajg`)) {
const ara = fs.readFileSync('./sticker/anime/toxic.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`Assalamualaikum`)) {
const ara = fs.readFileSync('./sticker/anime/Assalamualaikum.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }               
if (budy.includes(`assalamualaikum`)) {
const ara = fs.readFileSync('./sticker/anime/Assalamualaikum.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }                     
if (budy.includes(`ajg`)) {
const ara = fs.readFileSync('./sticker/anime/toxic.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`bangsat`)) {
const ara = fs.readFileSync('./sticker/anime/toxic.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`kntl`)) {
const ara = fs.readFileSync('./sticker/anime/toxic.webp');
mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`${owner}`,)) {              
                  const ara = fs.readFileSync('./sticker/anime/tag.webp');
                  mario4647.sendMessage(from, ara, MessageType.sticker, {quoted: mek})
                  }
if (budy.includes(`bot`)) {

                  reply(`Iya gw Bot, Gak seneng lu?`)

                  }


		if (budy.includes(`Assalamualaikum`)) {

                  reply(`Waalaikumsalam ${pushname}`)

                  }


		if (budy.includes(`P`)) {

                  reply(`Pa pe pa pe, Salam gblk`)

                  }


		if (budy.includes(`Kontol`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`Ngentod`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`Kntl`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`Memek`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`memek`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`jembut`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`kontol`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`anj`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`Anjg`)) {

                  reply(`_Jangan Toxic anj_`)

                  }


		if (budy.includes(`Bacot`)) {

                  reply(`Napa lu?`)

                  }
default:
if (isOwner) {
			if (budy.startsWith('>')) {
				console.log(color('[EVAL1]'), color(moment(mek.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`eval return`))
				try {
					let evaled = await eval(budy.slice(2))
					if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
					reply(`${evaled}`)
				} catch (err) {
					reply(`${err}`)
				}
			} else if (budy.startsWith('x')) {
				console.log(color('[EVAL2]'), color(moment(mek.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`eval identy`))
				try {
					return mario4647.sendMessage(from, JSON.stringify(eval(budy.slice(2)), null, '\t'), text, { quoted: ftrol })
				} catch (err) {
					e = String(err)
					reply(e)
				}
			}
		}
		}
	} catch (e) {
    e = String(e)
    if (!e.includes("this.isZero") && !e.includes("jid")) {
	console.log('Error : %s', color(e, 'red'))
        }
	// console.log(e)
	}
}


	
    
