# const : High Level Security
# Mario4647 Is Creator In File Js/Json
# const S&K arabotznew
┌────────────
│Base : Mario4647
│Func : Security System
│Risk of Banned If There Are Unnatural Changes To Files
└────────────

Is User IP In File arabotznew :

1.
# Phone Name : Oppo A93
# Phone IP User : 71.841.32.980
# IMEI : 359102517101
# Change Settings : ara.js 52:53, main.js 20:21

2.
# Phone Name : Oppo A71
# Phone IP User : 784.21.0.27
# IMEI : 35917180013
# Change Settings : ara.js 52:53, ara.js 70:93, main.js 20:21