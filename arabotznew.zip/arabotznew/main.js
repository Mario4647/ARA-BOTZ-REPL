const {
    WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange
} = require('@adiwajshing/baileys')
const fs = require('fs')
const moment = require('moment-timezone')
const { wait, banner, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, start, info, success, close } = require('./lib/functions')
const { color } = require('./lib/color')
const _welkom = JSON.parse(fs.readFileSync('./database/welcome.json'))

require('./ara.js')
nocache('./ara.js', module => console.log(`${module} Baru Saja Di Perbarui`))

const starts = async (mario4647 = new WAConnection()) => {
    mario4647.logger.level = 'warn'
    mario4647.version = [2, 2140, 13]
    mario4647.browserDescription = [ 'Mario 4647', 'Safari', '3.0' ]
    console.log(color('[ ! ] File Ini Telah Di Pasang Security System Controler\nJika Anda Merubah-Rubah Nama Creator Maka Alamat IP Dan IMEI\nAkan Terdeteksi Dan Akan Di Ban IP Secara Permanen','red'))
    console.log(banner)
    mario4647.on('qr', () => {
        console.log(color('[','white'), color('!','red'), color(']','white'), color(' Scan Qr Di Atas Agar Bot Dapat Terhubung Ke Whats App Mu'))
    })
      const sendButImage = async (from, context, fotext, img, but) => {
    gam = img
    jadinya = await mario4647.prepareMessage(from, gam, MessageType.image)
    buttonMessagesI = {
      imageMessage: jadinya.message.imageMessage,
      contentText: context,
      footerText: fotext,
      buttons: but,
      headerType: 4
    }
    mario4647.sendMessage(from, buttonMessagesI, MessageType.buttonsMessage)
  }

    fs.existsSync('./ara.json') && mario4647.loadAuthInfo('./ara.json')
    mario4647.on('connecting', () => {
        start('2', '.')
    })
    mario4647.on('open', () => {
        success('2', '[ CNT ] Connected Mario 4647')
    })
    await mario4647.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./ara.json', JSON.stringify(mario4647.base64EncodedAuthInfo(), null, '\t'))

    mario4647.on('chat-update', async (message) => {
        require('./ara.js')(mario4647, message, _welkom)
    })
mario4647.on("group-participants-update", async (anu) => {

    const isWelkom = _welkom.includes(anu.jid)
    try {
      groupMet = await mario4647.groupMetadata(anu.jid)
      groupMembers = groupMet.participants
      groupAdmins = getGroupAdmins(groupMembers)
      mem = anu.participants[0]

      console.log(anu)
      try {
        pp_user = await mario4647.getProfilePicture(mem)
      } catch (e) {
        pp_user = "https://www.linkpicture.com/q/20211125_113714.jpg"
      }
      try {
        pp_grup = await mario4647.getProfilePicture(anu.jid)
      } catch (e) {
        pp_grup =
          "https://www.linkpicture.com/q/20211125_113714.jpg"
      }
      if (anu.action == "add" && mem.includes(mario4647.user.jid)) {
        mario4647.sendMessage(anu.jid, "Hay Semua Saya Ara Botz Saya Di Masukan Ke Grub Oleh Mario 4647,Untuk Memulai Bot Silahkan Ketik #menu", "conversation")
      }
      if (!isWelkom) return
      if (anu.action == "add" && !mem.includes(mario4647.user.jid)) {
        mdata = await mario4647.groupMetadata(anu.jid)
        memeg = mdata.participants.length
        num = anu.participants[0]
        let v = mario4647.contacts[num] || { notify: num.replace(/@.+/, "") }
        anu_user = v.vname || v.notify || num.split("@")[0]
        time_wel = moment.tz("Asia/Jakarta").format("HH:mm")
        wel = `*Selamat Datang @${num.split("@")[0]} 👋*\n\n*Silahkan Intro Terlebih Dahulu Yak👋*\n*📛NAMA :*\n*📆UMUR :*\n*📅KELAS :*\n*👤GENDER :*\n*♨ASAL :*`
        buff = await getBuffer(
          `http://hadi-api.herokuapp.com/api/card/welcome?nama=${anu_user}&descriminator=${groupMembers.length
          }&memcount=${memeg}&gcname=${encodeURI(
            mdata.subject
          )}&pp=${pp_user}&bg=https://www.linkpicture.com/q/20211125_113317.jpg`
        )

        but = [
          { buttonId: 'add', buttonText: { displayText: 'Selamat Datang🍃' }, type: 1 }
        ]
        sendButImage(mdata.id, wel, "Â©Created : Mario 4647", buff, but)
      }
      if (!isWelkom) return
      if (anu.action == "remove" && !mem.includes(mario4647.user.jid)) {
        mdata = await mario4647.groupMetadata(anu.jid)
        num = anu.participants[0]
        let w = mario4647.contacts[num] || { notify: num.replace(/@.+/, "") }
        anu_user = w.vname || w.notify || num.split("@")[0]
        time_wel = moment.tz("Asia/Jakarta").format("HH:mm")
        memeg = mdata.participants.length
        out = `Sayonara @${num.split("@")[0]} ðŸ‘‹\nLain Kali Balik Ya,Kalo Balik Jangan Lupa Beliin Kuota Buat Member GrubðŸ˜‡`
        buff = await getBuffer(
          `http://hadi-api.herokuapp.com/api/card/goodbye?nama=${anu_user}&descriminator=${groupMembers.length
          }&memcount=${memeg}&gcname=${encodeURI(
            mdata.subject
          )}&pp=${pp_user}&bg=https://www.linkpicture.com/q/20211125_113317.jpg`
        )

        but = [
          { buttonId: 'remove', buttonText: { displayText: 'Selamat Tinggal🌸' }, type: 1 }
        ]
        sendButImage(mdata.id, out, "Â©Created : Mario 4647", buff, but)
      }
      if (anu.action == "promote") {
        const mdata = await mario4647.groupMetadata(anu.jid)
        anu_user = mario4647.contacts[mem]
        num = anu.participants[0]
        try {
          ppimg = await mario4647.getProfilePicture(
            `${anu.participants[0].split("@")[0]}@c.us`
          )
        } catch {
          ppimg =
            "https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg"
        }
        let buff = await getBuffer(ppimg)
        teks = `Selamat  Kak @${num.split("@")[0]} Anda Telah Menjadi Admin Grub,Tolong Jaga Grub Ini Dengan Baik Yak`
        mario4647.sendMessage(mdata.id, teks, MessageType.text)
      }

      if (anu.action == "demote") {
        anu_user = mario4647.contacts[mem]
        num = anu.participants[0]
        const mdata = await mario4647.groupMetadata(anu.jid)
        try {
          ppimg = await mario4647.getProfilePicture(
            `${anu.participants[0].split("@")[0]}@c.us`
          )
        } catch {
          ppimg =
            "https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg"
        }

        let buff = await getBuffer(
          `https://gatauajg.yogipw.repl.co/api/demote?name=${anu_user.notify}&msg=selamat%20menjadi%20admin&mem=5&picurl=${ppimg}&bgurl=https://cdn.discordapp.com/attachments/819995259261288475/835055559941292032/style.jpg`
        )
        teks = `@${num.split("@")[0]} Yahh Logo Admin Kamu Ilang:v`
        mario4647.sendMessage(mdata.id, teks, MessageType.text)
      }
    } catch (e) {
      console.log("Error : %s", color(e, "red"))
    }

  })
}

/**
 * Uncache if there is file change
 * @param {string} module Module name or path
 * @param {function} cb <optional> 
 */
function nocache(module, cb = () => { }) {
    console.log('File', `./ara.js`, 'Sekarang Telah Di Awasi Dengan Ketat')
    console.log('File', `./main.js`, 'Sekarang Telah Di Awasi Dengan Ketat')
    console.log('File', `./functions.js`, 'Sekarang Telah Di Awasi Dengan Ketat')
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
}

/**
 * Uncache a module
 * @param {string} module Module name or path
 */
function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
}

starts()
